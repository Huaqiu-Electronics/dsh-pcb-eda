package app.freerouting.gui.workspace.progress;

import app.freerouting.board.facade.BasicBoard;
import app.freerouting.board.model.items.Item;
import app.freerouting.drc.AirLine;
import app.freerouting.drc.DesignRulesChecker;
import app.freerouting.drc.NetIncompletes;
import app.freerouting.geometry.planar.Point;
import app.freerouting.gui.rendering.GraphicsContext;
import app.freerouting.gui.rendering.NetIncompletesGraphics;
import app.freerouting.logger.FRLogger;
import java.awt.Graphics;
import java.util.Collection;

/**
 * Manages the visual representation of incomplete connections (rats nest) on the PCB board.
 *
 * <p>A "rats nest" or "air wires" refers to the display of unrouted connections between pins that
 * need to be connected. These are shown as straight lines (airlines) connecting the nearest points
 * of items that should be electrically connected but aren't yet routed.
 *
 * <p><strong>Key Responsibilities:</strong>
 *
 * <ul>
 *   <li><strong>Connection Analysis:</strong> Calculates which pins need to be connected
 *   <li><strong>Airline Generation:</strong> Creates visual lines showing unrouted connections
 *   <li><strong>Length Validation:</strong> Checks if routed traces meet length requirements
 *   <li><strong>Visibility Control:</strong> Manages display filtering per net or globally
 *   <li><strong>Graphics Rendering:</strong> Draws the rats nest on screen
 * </ul>
 *
 * <p><strong>Use Cases:</strong>
 *
 * <ul>
 *   <li>Visual feedback showing what connections remain to be routed
 *   <li>Identifying the shortest path between unconnected items
 *   <li>Monitoring routing progress (number of incomplete connections)
 *   <li>Detecting length matching violations for critical nets
 * </ul>
 *
 * <p><strong>Technical Details:</strong> Airlines connect the nearest points between items that
 * should be on the same net but are not physically connected. When multiple disconnected groups
 * exist on a net, multiple airlines will be shown. The rats nest is recalculated automatically when
 * items are added, moved, or removed from the board.
 *
 * @see DesignRulesChecker
 * @see AirLine
 * @see NetIncompletes
 */
public class RatsNest {

  /**
   * Design rules checker that performs incomplete connection calculations.
   *
   * <p>The DRC maintains the current state of all incomplete connections and provides methods to
   * recalculate them when the board changes. It analyzes connectivity between items and generates
   * airlines representing unrouted connections.
   *
   * @see DesignRulesChecker
   */
  public final DesignRulesChecker drc;

  /**
   * Per-net visibility filter array for selective rats nest display.
   *
   * <p>Array indexing: {@code isFiltered[i]} controls visibility for net number {@code (i+1)}.
   *
   * <ul>
   *   <li>{@code true}: Airlines for this net are hidden
   *   <li>{@code false}: Airlines for this net are visible (unless globally hidden)
   * </ul>
   *
   * <p>This allows users to focus on specific nets by hiding the rats nest clutter from other nets.
   */
  private final boolean[] isFiltered;

  /**
   * Global visibility flag for the entire rats nest display.
   *
   * <p>When {@code true}, all rats nest airlines are hidden regardless of individual net filters.
   * When {@code false}, airlines are shown according to per-net filters.
   *
   * <p>Typically set to {@code true} during interactive routing to reduce visual clutter while
   * actively routing traces.
   */
  public boolean hidden;

  /**
   * Creates a new RatsNest instance and performs initial incomplete connection analysis.
   *
   * <p>Initialization process:
   *
   * <ol>
   *   <li>Creates a DesignRulesChecker for the board
   *   <li>Calculates all incomplete connections across all nets
   *   <li>Initializes per-net visibility filters (all visible by default)
   * </ol>
   *
   * <p>The initial calculation analyzes the entire board to determine which items need connections
   * but aren't physically connected yet. This can be time-consuming on large boards with many nets.
   *
   * @param board the board containing nets and items to analyze for incomplete connections
   * @see DesignRulesChecker#calculateAllIncompletes()
   */
  public RatsNest(BasicBoard board) {
    this.drc = new DesignRulesChecker(board, null);
    this.drc.calculateAllIncompletes();

    int maxNetNo = board.rules.nets.maxNetNumber();
    this.isFiltered = new boolean[maxNetNo];
    for (int i = 0; i < maxNetNo; i++) {
      isFiltered[i] = false;
    }
  }

  /**
   * Recalculates incomplete connections (airlines) for the specified net.
   *
   * <p>Called after board modifications that affect connectivity, such as:
   *
   * <ul>
   *   <li>Adding or removing traces
   *   <li>Adding or removing vias
   *   <li>Moving components
   *   <li>Deleting items
   * </ul>
   *
   * <p>The recalculation determines which items on the net are electrically connected and which
   * require routing, updating the airline display accordingly.
   *
   * @param netNumber the net number to recalculate (must be valid)
   * @param board the board containing the items (provided for context)
   * @see DesignRulesChecker#recalculateNetIncompletes(int)
   */
  public void recalculate(int netNumber, BasicBoard board) {
    drc.recalculateNetIncompletes(netNumber);
  }

  /**
   * Recalculates incomplete connections for the specified net using a provided item collection.
   *
   * <p>This optimized variant only analyzes the provided items instead of searching the entire
   * board. More efficient when the affected items are already known, such as:
   *
   * <ul>
   *   <li>After moving or modifying specific components
   *   <li>During partial board updates
   *   <li>When working with a pre-filtered item set
   * </ul>
   *
   * <p>The item collection should include all items on the net that may have changed connectivity
   * status.
   *
   * @param netNumber the net number to recalculate
   * @param itemList the collection of items to analyze for this net
   * @param board the board context (provided for completeness)
   * @see DesignRulesChecker#recalculateNetIncompletes(int, Collection)
   */
  public void recalculate(int netNumber, Collection<Item> itemList, BasicBoard board) {
    drc.recalculateNetIncompletes(netNumber, itemList);
  }

  /**
   * Returns the total number of incomplete connections (airlines) across all nets on the board.
   *
   * <p>Important notes:
   *
   * <ul>
   *   <li>Each airline represents one disconnected segment requiring routing
   *   <li>A single net with multiple isolated groups generates multiple airlines
   *   <li>The count can exceed the number of nets with incomplete connections
   *   <li>A count of 0 indicates a fully routed board
   * </ul>
   *
   * <p><strong>Example:</strong> A net with 4 pins split into 2 groups (A-B and C-D) will have 1
   * airline connecting the groups, even though 2 connections need to be routed.
   *
   * @return the total count of airlines across all nets
   * @see #incompleteCount(int)
   * @see DesignRulesChecker#getIncompleteCount()
   */
  public int incompleteCount() {
    int result = drc.getIncompleteCount();
    StringBuilder perNet = new StringBuilder();
    for (int netNumber = 1; netNumber <= this.isFiltered.length; netNumber++) {
      int netIncomplete = drc.getIncompleteCount(netNumber);
      if (netIncomplete > 0) {
        if (!perNet.isEmpty()) {
          perNet.append(',');
        }
        perNet.append(netNumber).append('=').append(netIncomplete);
      }
    }
    FRLogger.trace(
        "RatsNest.incompleteCount",
        "total_incomplete_count",
        "RatsNest total incomplete count=" + result,
        "RatsNest",
        new Point[0]);
    FRLogger.trace(
        "RatsNest.incompleteCount",
        "net_breakdown",
        "RatsNest incomplete net breakdown=" + perNet,
        "RatsNest",
        new Point[0]);
    return result;
  }

  /**
   * Returns the number of incomplete connections for a specific net.
   *
   * <p>This count represents how many disconnected groups exist on the net. A fully connected net
   * returns 0. A net with n disconnected groups typically has (n-1) airlines connecting them.
   *
   * <p>Useful for:
   *
   * <ul>
   *   <li>Monitoring routing progress on a specific net
   *   <li>Identifying nets requiring attention
   *   <li>Validating that critical nets are fully routed
   * </ul>
   *
   * @param netNumber the net number to check
   * @return the count of airlines for this net, or 0 if fully connected
   * @see #incompleteCount()
   * @see DesignRulesChecker#getIncompleteCount(int)
   */
  public int incompleteCount(int netNumber) {
    int result = drc.getIncompleteCount(netNumber);
    FRLogger.trace(
        "RatsNest.incompleteCount",
        "net_incomplete_count",
        "RatsNest net=" + netNumber + " incompleteCount=" + result,
        "Net #" + netNumber,
        new Point[0]);
    return result;
  }

  /**
   * Returns the total number of nets with length matching violations.
   *
   * <p>Length violations occur when routed traces don't meet specified requirements:
   *
   * <ul>
   *   <li><strong>Too short:</strong> Trace length is below minimum requirement
   *   <li><strong>Too long:</strong> Trace length exceeds maximum limit
   * </ul>
   *
   * <p>Common use cases for length constraints:
   *
   * <ul>
   *   <li>High-speed differential pairs (matched lengths required)
   *   <li>DDR memory signals (strict length matching)
   *   <li>Clock distribution (controlled delays)
   *   <li>Impedance-controlled traces
   * </ul>
   *
   * <p>A count of 0 indicates all length-constrained nets are within tolerance.
   *
   * @return the number of nets violating length restrictions
   * @see #getLengthViolation(int)
   * @see DesignRulesChecker#getLengthViolationCount()
   */
  public int lengthViolationCount() {
    return drc.getLengthViolationCount();
  }

  /**
   * Returns the magnitude of the length violation for the specified net.
   *
   * <p>Return value interpretation:
   *
   * <ul>
   *   <li><strong>Positive value:</strong> Trace is too long by this amount
   *   <li><strong>Negative value:</strong> Trace is too short by this amount (absolute value)
   *   <li><strong>Zero:</strong> Net is within acceptable length range or has no restrictions
   * </ul>
   *
   * <p>The violation magnitude is in board units and represents how far the actual trace length
   * deviates from the acceptable range.
   *
   * <p><strong>Example:</strong> A return value of +50 means the trace is 50 units longer than the
   * maximum allowed length.
   *
   * @param netNumber the net number to check
   * @return positive if too long, negative if too short, 0 if valid or unrestricted
   * @see #lengthViolationCount()
   * @see DesignRulesChecker#getLengthViolation(int)
   */
  public double getLengthViolation(int netNumber) {
    return drc.getLengthViolation(netNumber);
  }

  /**
   * Retrieves all airlines (incomplete connections) for the entire board.
   *
   * <p>Returns an array containing all AirLine objects representing unrouted connections across all
   * nets. Each AirLine contains:
   *
   * <ul>
   *   <li>Start and end points of the connection
   *   <li>Net number the connection belongs to
   *   <li>Layer information
   * </ul>
   *
   * <p>Useful for:
   *
   * <ul>
   *   <li>Custom visualization or analysis of incomplete connections
   *   <li>Exporting rats nest information
   *   <li>Algorithmic processing of routing requirements
   * </ul>
   *
   * @return an array containing all AirLine objects, or empty array if fully routed
   * @see AirLine
   * @see DesignRulesChecker#getAllAirlines()
   */
  public AirLine[] getAirlines() {
    return drc.getAllAirlines();
  }

  /**
   * Hides the rats nest globally, suppressing all airline displays.
   *
   * <p>When hidden, no airlines are drawn regardless of per-net filter settings. This is typically
   * used during interactive routing to reduce visual clutter, allowing the user to focus on the
   * trace being routed.
   *
   * <p>Length violation indicators may still be displayed depending on implementation settings.
   *
   * @see #show()
   * @see #isHidden()
   */
  public void hide() {
    hidden = true;
  }

  /**
   * Shows the rats nest, making airlines visible according to per-net filters.
   *
   * <p>Clears the global hidden flag, allowing airlines to be displayed for nets that are not
   * individually filtered. Airlines for filtered nets remain hidden.
   *
   * @see #hide()
   * @see #setFilter(int, boolean)
   */
  public void show() {
    hidden = false;
  }

  /**
   * Recalculates length matching violations for all nets with length constraints.
   *
   * <p>This method:
   *
   * <ul>
   *   <li>Recomputes actual trace lengths for all nets
   *   <li>Compares them against minimum/maximum length requirements
   *   <li>Updates the violation status for each net
   * </ul>
   *
   * <p>Should be called after routing changes that might affect trace lengths, such as
   * optimization, pull-tight, or manual trace adjustments.
   *
   * @return true if any net's violation status changed (new violations or fixes), false otherwise
   * @see #lengthViolationCount()
   * @see #getLengthViolation(int)
   * @see DesignRulesChecker#recalculateLengthViolations()
   */
  public boolean recalculateLengthViolations() {
    return drc.recalculateLengthViolations();
  }

  /**
   * Checks if the rats nest is globally hidden.
   *
   * <p>Returns the state of the global visibility flag. When true, all airlines are suppressed
   * regardless of per-net filter settings. Commonly used to:
   *
   * <ul>
   *   <li>Reduce visual clutter during interactive routing
   *   <li>Conditionally disable rats nest updates for performance
   *   <li>Determine whether to draw length violations only
   * </ul>
   *
   * @return true if the rats nest is globally hidden, false if visible (subject to filters)
   * @see #hide()
   * @see #show()
   */
  public boolean isHidden() {
    return hidden;
  }

  /**
   * Sets the visibility filter for a specific net's rats nest airlines.
   *
   * <p>Filter behavior:
   *
   * <ul>
   *   <li><strong>value = true:</strong> Hide airlines for this net
   *   <li><strong>value = false:</strong> Show airlines for this net (if not globally hidden)
   * </ul>
   *
   * <p>Per-net filtering allows users to focus on specific routing tasks by hiding irrelevant
   * airlines. The filter is ignored if the rats nest is globally hidden.
   *
   * <p>If the net number is out of valid range (less than 1 or greater than the maximum net
   * number), the operation is silently ignored.
   *
   * @param netNumber the net number to filter (1-based indexing)
   * @param value true to hide the net's airlines, false to show them
   * @see #isHidden()
   * @see #draw(Graphics, GraphicsContext)
   */
  public void setFilter(int netNumber, boolean value) {
    if (netNumber < 1 || netNumber > isFiltered.length) {
      return;
    }
    isFiltered[netNumber - 1] = value;
  }

  /**
   * Draws the rats nest airlines to the graphics context.
   *
   * <p>Drawing behavior:
   *
   * <ul>
   *   <li><strong>If globally hidden:</strong> Only length violations are drawn (if any)
   *   <li><strong>If visible:</strong> Airlines are drawn for non-filtered nets
   * </ul>
   *
   * <p>The method iterates through all nets, checking their filter status and delegating the actual
   * rendering to NetIncompletesGraphics. Airlines are drawn as straight lines from the nearest
   * points between disconnected item groups.
   *
   * <p>Color and style are determined by the graphics context settings, typically using distinctive
   * colors for different net classes or violation types.
   *
   * @param graphics the AWT Graphics object for rendering
   * @param graphicsContext the context managing board graphics (colors, transforms, layers)
   * @see NetIncompletesGraphics#draw
   * @see GraphicsContext
   */
  public void draw(Graphics graphics, GraphicsContext graphicsContext) {
    boolean drawLengthViolationsOnly = this.hidden;

    for (int i = 0; i < isFiltered.length; i++) {
      // net index to net number: i -> i+1
      if (!isFiltered[i]) {
        NetIncompletes ni = drc.getNetIncompletes(i + 1);
        if (ni != null) {
          NetIncompletesGraphics.draw(ni, graphics, graphicsContext, drawLengthViolationsOnly);
        }
      }
    }
  }
}
