package app.freerouting.io.specctra;

import app.freerouting.board.facade.BasicBoard;
import app.freerouting.board.model.structure.AngleRestriction;
import app.freerouting.io.CoordinateTransform;
import app.freerouting.io.specctra.parser.AutorouteSettings;
import app.freerouting.io.specctra.parser.IJFlexScanner;
import app.freerouting.io.specctra.parser.Keyword;
import app.freerouting.io.specctra.parser.LayerStructure;
import app.freerouting.io.specctra.parser.Library;
import app.freerouting.io.specctra.parser.NetClass;
import app.freerouting.io.specctra.parser.Network;
import app.freerouting.io.specctra.parser.Rule;
import app.freerouting.io.specctra.parser.ScopeKeyword;
import app.freerouting.io.specctra.parser.SpecctraDsnStreamReader;
import app.freerouting.io.specctra.parser.Structure;
import app.freerouting.logger.FRLogger;
import app.freerouting.rules.ViaInfo;
import app.freerouting.settings.RouterSettings;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;

/**
 * Reads a Specctra {@code .rules} file and applies the parsed rules directly to a {@link
 * BasicBoard}, without any dependency on {@link app.freerouting.gui.workspace.GuiBoardManager}.
 *
 * <p>This class is the public read entry point for Specctra rules files.
 */
public final class RulesReader {

  private RulesReader() {}

  /**
   * Reads the rules from {@code in} and applies them to {@code board}.
   *
   * <p>The stream is closed by this method on return (success or failure).
   *
   * @param in source — closed by this method on completion
   * @param designName expected PCB design name in the rules header (mismatch is logged but does not
   *     abort the read)
   * @param board the board to which parsed rules are applied
   * @return {@code true} if the rules were parsed and applied successfully; {@code false} on any
   *     parse or I/O error
   */
  public static boolean read(InputStream in, String designName, BasicBoard board) {
    return read(in, designName, board, null);
  }

  /**
   * Reads the rules from {@code in} and applies them to {@code board} and optional {@code
   * targetSettings}.
   *
   * <p>The stream is closed by this method on return (success or failure).
   *
   * @param in source — closed by this method on completion
   * @param designName expected PCB design name in the rules header (mismatch is logged but does not
   *     abort the read)
   * @param board the board to which parsed rules are applied
   * @param targetSettings optional router settings to update with parsed autoroute_settings
   * @return {@code true} if the rules were parsed and applied successfully; {@code false} on any
   *     parse or I/O error
   */
  public static boolean read(
      InputStream in, String designName, BasicBoard board, RouterSettings targetSettings) {
    if (in == null) {
      FRLogger.warn("RulesReader.read: input stream is null");
      return false;
    }
    if (board == null) {
      FRLogger.warn("RulesReader.read: board is null");
      closeQuietly(in);
      return false;
    }

    IJFlexScanner scanner = new SpecctraDsnStreamReader(in);
    try {
      // Validate the "(rules PCB <name>" header
      Object currentToken = scanner.nextToken();
      if (currentToken != Keyword.OPEN_BRACKET) {
        FRLogger.warn(
            "RulesReader.read: open bracket expected at '" + scanner.getScopeIdentifier() + "'");
        return false;
      }
      currentToken = scanner.nextToken();
      if (currentToken != Keyword.RULES) {
        FRLogger.warn(
            "RulesReader.read: keyword 'rules' expected at '" + scanner.getScopeIdentifier() + "'");
        return false;
      }
      currentToken = scanner.nextToken();
      if (currentToken != Keyword.PCB_SCOPE) {
        FRLogger.warn(
            "RulesReader.read: keyword 'pcb' expected at '" + scanner.getScopeIdentifier() + "'");
        return false;
      }
      scanner.yybegin(SpecctraDsnStreamReader.NAME);
      currentToken = scanner.nextToken();
      if (!(currentToken instanceof String) || !currentToken.equals(designName)) {
        FRLogger.warn(
            "RulesReader.read: designName not matching at '"
                + scanner.getScopeIdentifier()
                + "' (expected '"
                + designName
                + "', got '"
                + currentToken
                + "')");
        // non-fatal: continue reading
      }

      LayerStructure layerStructure = new LayerStructure(board.layerStructure);
      CoordinateTransform coordinateTransform = board.communication.coordinateTransform;

      // Parse all top-level scopes in the rules body
      Object nextToken = null;
      for (; ; ) {
        final Object prevToken = nextToken;
        try {
          nextToken = scanner.nextToken();
        } catch (IOException e) {
          FRLogger.error("RulesReader.read: IO error scanning rules body", e);
          return false;
        }
        if (nextToken == null) {
          FRLogger.warn(
              "RulesReader.read: unexpected end of file at '" + scanner.getScopeIdentifier() + "'");
          return false;
        }
        if (nextToken == Keyword.CLOSED_BRACKET) {
          // end of (rules ...) scope — success
          break;
        }
        if (prevToken == Keyword.OPEN_BRACKET) {
          if (nextToken == Keyword.RULE) {
            applyRules(Rule.readScope(scanner), board, null);
          } else if (nextToken == Keyword.LAYER) {
            applyLayerRules(scanner, board);
          } else if (nextToken == Keyword.PADSTACK) {
            Library.readPadstackScope(
                scanner, layerStructure, coordinateTransform, board.library.padstacks);
          } else if (nextToken == Keyword.VIA) {
            applyViaInfo(scanner, board);
          } else if (nextToken == Keyword.VIA_RULE) {
            applyViaRule(scanner, board);
          } else if (nextToken == Keyword.CLASS) {
            applyNetClass(scanner, layerStructure, board);
          } else if (nextToken == Keyword.SNAP_ANGLE) {
            AngleRestriction snapAngle = Structure.readSnapAngle(scanner);
            if (snapAngle != null) {
              board.rules.setTraceAngleRestriction(snapAngle);
            }
          } else if (nextToken == Keyword.AUTOROUTE_SETTINGS) {
            RouterSettings parsedSettings = AutorouteSettings.readScope(scanner, layerStructure);
            if (targetSettings != null && parsedSettings != null) {
              targetSettings.applyNewValuesFrom(parsedSettings);
            }
          } else {
            ScopeKeyword.skipScope(scanner);
          }
        }
      }
      return true;
    } catch (IOException e) {
      FRLogger.error("RulesReader.read: IO error scanning rules header", e);
      return false;
    } finally {
      closeQuietly(in);
    }
  }

  /**
   * Reads only the {@link RouterSettings} from a rules file stream.
   *
   * <p>The stream is closed by this method on return.
   *
   * @param in source stream
   * @return extracted {@link RouterSettings}, or {@code null} if not found or on error
   */
  public static RouterSettings readRouterSettings(InputStream in) {
    if (in == null) {
      return null;
    }
    byte[] data;
    try {
      data = in.readAllBytes();
    } catch (IOException e) {
      FRLogger.error("RulesReader.readRouterSettings: error reading stream", e);
      return null;
    } finally {
      closeQuietly(in);
    }

    if (data.length == 0) {
      return null;
    }

    LayerStructure layerStructure = discoverLayerStructure(data);
    IJFlexScanner scanner = new SpecctraDsnStreamReader(new ByteArrayInputStream(data));
    try {
      // Validate header
      Object currentToken = scanner.nextToken();
      if (currentToken != Keyword.OPEN_BRACKET) {
        return null;
      }
      currentToken = scanner.nextToken();
      if (currentToken != Keyword.RULES) {
        return null;
      }
      currentToken = scanner.nextToken();
      if (currentToken != Keyword.PCB_SCOPE) {
        return null;
      }
      scanner.yybegin(SpecctraDsnStreamReader.NAME);
      scanner.nextToken(); // designName

      Object nextToken = null;
      for (; ; ) {
        final Object prevToken = nextToken;
        nextToken = scanner.nextToken();
        if (nextToken == null || nextToken == Keyword.CLOSED_BRACKET) {
          break;
        }
        if (prevToken == Keyword.OPEN_BRACKET) {
          if (nextToken == Keyword.AUTOROUTE_SETTINGS) {
            return AutorouteSettings.readScope(scanner, layerStructure);
          } else {
            ScopeKeyword.skipScope(scanner);
          }
        }
      }
    } catch (IOException e) {
      FRLogger.error("RulesReader.readRouterSettings: IO error scanning file", e);
    }
    return null;
  }

  private static LayerStructure discoverLayerStructure(byte[] data) {
    java.util.LinkedHashSet<String> layerNames = new java.util.LinkedHashSet<>();
    IJFlexScanner scanner = new SpecctraDsnStreamReader(new java.io.ByteArrayInputStream(data));
    try {
      Object token = null;
      for (; ; ) {
        Object prev = token;
        token = scanner.nextToken();
        if (token == null) {
          break;
        }
        if (prev == Keyword.OPEN_BRACKET) {
          if (token == Keyword.LAYER_RULE || token == Keyword.LAYER) {
            scanner.yybegin(SpecctraDsnStreamReader.NAME);
            Object nameToken = scanner.nextToken();
            if (nameToken instanceof String s && !s.isBlank()) {
              layerNames.add(s);
            }
          }
        }
      }
    } catch (IOException _) {
      // ignore
    }

    if (layerNames.isEmpty()) {
      layerNames.add("F.Cu");
      layerNames.add("B.Cu");
    }

    java.util.List<app.freerouting.io.specctra.parser.Layer> list = new java.util.ArrayList<>();
    int idx = 0;
    for (String name : layerNames) {
      list.add(new app.freerouting.io.specctra.parser.Layer(name, idx++, true));
    }
    return new LayerStructure(list);
  }

  // -------------------------------------------------------------------------
  // Private helpers for rules-file parsing.
  // -------------------------------------------------------------------------

  private static void applyRules(Collection<Rule> rules, BasicBoard board, String layerName) {
    if (rules == null) {
      return;
    }
    int layerIndex = -1;
    if (layerName != null) {
      layerIndex = board.layerStructure.getNo(layerName);
      if (layerIndex < 0) {
        FRLogger.warn("RulesReader.applyRules: layer not found: '" + layerName + "'");
      }
    }
    CoordinateTransform coordinateTransform = board.communication.coordinateTransform;
    String stringQuote = board.communication.specctraParserInfo.stringQuote;
    for (Rule rule : rules) {
      if (rule instanceof Rule.WidthRule widthRule) {
        int traceHalfwidth = (int) Math.round(coordinateTransform.dsnToBoard(widthRule.value) / 2);
        if (layerIndex < 0) {
          board.rules.setDefaultTraceHalfWidths(traceHalfwidth);
        } else {
          board.rules.setDefaultTraceHalfWidth(layerIndex, traceHalfwidth);
        }
      } else if (rule instanceof Rule.ClearanceRule clearanceRule) {
        Structure.setClearanceRule(
            clearanceRule, layerIndex, coordinateTransform, board.rules, stringQuote);
      }
    }
  }

  private static void applyLayerRules(IJFlexScanner scanner, BasicBoard board) {
    try {
      Object nextToken = scanner.nextToken();
      if (!(nextToken instanceof String layerString)) {
        FRLogger.warn(
            "RulesReader.applyLayerRules: String expected at '"
                + scanner.getScopeIdentifier()
                + "'");
        return;
      }
      nextToken = scanner.nextToken();
      while (nextToken != Keyword.CLOSED_BRACKET) {
        if (nextToken != Keyword.OPEN_BRACKET) {
          FRLogger.warn(
              "RulesReader.applyLayerRules: '(' expected at '"
                  + scanner.getScopeIdentifier()
                  + "'");
          return;
        }
        nextToken = scanner.nextToken();
        if (nextToken == Keyword.RULE) {
          applyRules(Rule.readScope(scanner), board, layerString);
        } else {
          ScopeKeyword.skipScope(scanner);
        }
        nextToken = scanner.nextToken();
      }
    } catch (IOException e) {
      FRLogger.error("RulesReader.applyLayerRules: IO error scanning file", e);
    }
  }

  private static void applyViaInfo(IJFlexScanner scanner, BasicBoard board) {
    ViaInfo viaInfo = Network.readViaInfo(scanner, board);
    if (viaInfo == null) {
      return;
    }
    ViaInfo existing = board.rules.viaInfos.get(viaInfo.getName());
    if (existing != null) {
      board.rules.viaInfos.remove(existing);
    }
    board.rules.viaInfos.add(viaInfo);
  }

  private static void applyViaRule(IJFlexScanner scanner, BasicBoard board) {
    Collection<String> viaRule = Network.readViaRule(scanner, board);
    if (viaRule != null) {
      Network.addViaRule(viaRule, board);
    }
  }

  private static void applyNetClass(
      IJFlexScanner scanner, LayerStructure layerStructure, BasicBoard board) {
    NetClass netClass = NetClass.readScope(scanner);
    if (netClass == null) {
      return;
    }
    Network.insertNetClass(
        netClass, layerStructure, board, board.communication.coordinateTransform, false);
  }

  private static void closeQuietly(InputStream stream) {
    try {
      stream.close();
    } catch (IOException _) {
      // ignore
    }
  }
}
