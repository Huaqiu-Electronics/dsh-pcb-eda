package app.freerouting.board.facade;

import app.freerouting.autoroute.maze.AutorouteControl;
import app.freerouting.board.actions.ItemSelectionFilter;
import app.freerouting.board.model.items.ComponentObstacleArea;
import app.freerouting.board.model.items.ComponentOutline;
import app.freerouting.board.model.items.ConductionArea;
import app.freerouting.board.model.items.Connectable;
import app.freerouting.board.model.items.Item;
import app.freerouting.board.model.items.ObstacleArea;
import app.freerouting.board.model.items.Pin;
import app.freerouting.board.model.items.Trace;
import app.freerouting.board.model.items.Via;
import app.freerouting.board.model.items.ViaObstacleArea;
import app.freerouting.board.model.structure.BoardOutline;
import app.freerouting.board.model.structure.Components;
import app.freerouting.board.model.structure.FixedState;
import app.freerouting.board.model.structure.LayerStructure;
import app.freerouting.board.searchtree.SearchTreeManager;
import app.freerouting.board.searchtree.SearchTreeObject;
import app.freerouting.board.searchtree.ShapeSearchTree;
import app.freerouting.board.state.ChangedArea;
import app.freerouting.board.state.Communication;
import app.freerouting.board.trace.PolylineTrace;
import app.freerouting.core.library.BoardLibrary;
import app.freerouting.core.library.Padstack;
import app.freerouting.datastructures.ShapeTree.TreeEntry;
import app.freerouting.datastructures.UndoableObjects;
import app.freerouting.drc.NetRoutingLedger;
import app.freerouting.geometry.planar.Area;
import app.freerouting.geometry.planar.ConvexShape;
import app.freerouting.geometry.planar.IntBox;
import app.freerouting.geometry.planar.IntOctagon;
import app.freerouting.geometry.planar.Point;
import app.freerouting.geometry.planar.Polyline;
import app.freerouting.geometry.planar.PolylineShape;
import app.freerouting.geometry.planar.TileShape;
import app.freerouting.geometry.planar.Vector;
import app.freerouting.logger.FRLogger;
import app.freerouting.rules.BoardRules;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.CompletableFuture;

/**
 * Provides basic functionality of a board with geometric items. It contains functions such as
 * inserting, deleting, modifying and picking items and elementary checking functions. A board may
 * have one or several layers.
 */
public class BasicBoard implements Serializable {

  private static final long serialVersionUID = 4469140260760845555L;

  /**
   * The maximum number of outer-loop iterations in {@link #normalizeTraces}. Each legitimate
   * split/combine operation converges the board toward a stable state, so a well-formed net needs
   * at most a small multiple of its trace count. If we exceed this bound we are almost certainly
   * oscillating (split → combine → split …) and must break out.
   */
  private static final int MAX_NORMALIZE_ITERATIONS = 2000;

  /**
   * List of items inserted into this board (e.g. trace classes). Traces are Item classes that
   * implement the Connectable interface.
   */
  public final UndoableObjects itemList;

  /** List of placed components on the board. */
  public final Components components;

  /**
   * Class defining the rules for items to be inserted into this board. Contains for example the
   * clearance matrix.
   */
  public final BoardRules rules;

  /** The library containing padstack masks, packages and other templates used on the board. */
  public final BoardLibrary library;

  /** The layer structure of this board. */
  public final LayerStructure layerStructure;

  /** For communication with a host system or host design file formats. */
  public final Communication communication;

  /** Bounding orthogonal rectangle of this board. */
  public IntBox boundingBox;

  /** Handles the search trees pointing into the items of this board. */
  public transient SearchTreeManager searchTreeManager;

  private transient NetRoutingLedger routingLedger;

  private transient Set<Integer> normalizeSuppressedNetNos = new HashSet<>();
  private transient int revision;
  private transient BoardItemRepository itemRepository;
  private transient BoardConnectivityQueries connectivityQueries;
  private transient BoardSnapshotManager snapshotManager;
  public int preExistingClearanceViolationsCount = 0;
  public transient int unfixableClearanceViolationsCount = 0;
  public transient CompletableFuture<Void> postLoadFuture;

  /** The rectangle, where the graphics may be not up-to-date. */
  private transient IntBox updateBox = IntBox.EMPTY;

  /** The biggest half width of all traces on the board. */
  private int maxTraceHalfWidth = 1000;

  /** The smallest half width of all traces on the board. */
  private int minTraceHalfWidth = 10000;

  /**
   * Creates a new instance of a routing Board with surrounding box boundingBox Rules contains the
   * restrictions to obey when inserting items. Among other things it may contain a clearance
   * matrix. observers is used for synchronisation, if the board is generated by a host database,
   * otherwise it is null. If testLevel != RELEASE_VERSION, some features may be used, which are
   * still in experimental state. Warnings for debugging may be printed depending on the size of
   * testLevel.
   */
  public BasicBoard(
      IntBox boundingBox,
      LayerStructure layerStructure,
      PolylineShape[] outlineShapes,
      int outlineClClassNo,
      BoardRules rules,
      Communication communication) {
    this.layerStructure = layerStructure;
    this.rules = rules;
    library = new BoardLibrary();
    itemList = new UndoableObjects();
    components = new Components();
    this.communication = communication;
    this.boundingBox = boundingBox;
    searchTreeManager = new SearchTreeManager(this);
    rules.nets.setBoard(this);
    insertOutline(outlineShapes, outlineClClassNo);
  }

  /** Deserialize. */
  public static BasicBoard deserialize(byte[] objectByteArray) {
    return BoardSnapshotManager.deserialize(objectByteArray);
  }

  /**
   * Incomplete-connection counts maintained across inserts and removals. The counts match {@link
   * app.freerouting.drc.DesignRulesChecker#calculateAllIncompletes()}.
   */
  public NetRoutingLedger routingLedger() {
    if (routingLedger == null) {
      routingLedger = new NetRoutingLedger(this);
    }
    return routingLedger;
  }

  public int getRevision() {
    return revision;
  }

  /** Increment revision. */
  public void incrementRevision() {
    revision++;
  }

  /** Serialize. */
  public byte[] serialize(boolean basicProfile) {
    return getSnapshotManager().serialize(basicProfile);
  }

  /** Clone. */
  @Override
  public BasicBoard clone() {
    return BoardSnapshotManager.deserialize(getSnapshotManager().serialize(false));
  }

  /** Returns an MD5 hash of the board trace state. */
  public String getHash() {
    return getSnapshotManager().getHash();
  }

  /** Returns the number of trace ID differences compared to another board. */
  public int diffTraces(BasicBoard compareTo) {
    return getSnapshotManager().diffTraces(compareTo);
  }

  /**
   * Inserts a trace into the board, whose geometry is described by a Polyline. clearanceClass is
   * the index in the clearanceMatrix, which describes the required clearance restrictions to other
   * items. Because no internal cleaning of items is done, the new inserted item can be returned.
   */
  public PolylineTrace insertTraceWithoutCleaning(
      Polyline polyline,
      int layer,
      int halfWidth,
      int[] netNumbers,
      int clearanceClass,
      FixedState fixedState) {
    if (polyline.cornerCount() < 2) {
      return null;
    }
    PolylineTrace newTrace =
        new PolylineTrace(
            polyline, layer, halfWidth, netNumbers, clearanceClass, 0, 0, fixedState, this);
    if (newTrace.firstCorner().equals(newTrace.lastCorner())) {
      if (fixedState.ordinal() < FixedState.USER_FIXED.ordinal()) {
        return null;
      }
    }
    insertItem(newTrace);
    if (newTrace.netsNormal()) {
      maxTraceHalfWidth = Math.max(maxTraceHalfWidth, halfWidth);
      minTraceHalfWidth = Math.min(minTraceHalfWidth, halfWidth);
    }
    return newTrace;
  }

  /**
   * Inserts a trace into the board, whose geometry is described by a Polyline. clearanceClass is
   * the index in the clearanceMatrix, which describes the required clearance restrictions to other
   * items.
   */
  public void insertTrace(
      Polyline polyline,
      int layer,
      int halfWidth,
      int[] netNumbers,
      int clearanceClass,
      FixedState fixedState) {
    PolylineTrace newTrace =
        insertTraceWithoutCleaning(
            polyline, layer, halfWidth, netNumbers, clearanceClass, fixedState);
    if (newTrace == null) {
      return;
    }
    IntOctagon clipShape = null;
    if (this instanceof RoutingBoard board) {
      ChangedArea changedArea = board.changedArea;
      if (changedArea != null) {
        clipShape = changedArea.getArea(layer);
      }
    }

    try {
      newTrace.normalize(clipShape);
    } catch (Exception e) {
      // Normalization can fail for geometrically degenerate trace segments (e.g. caused by
      // malformed input geometry or extreme routing situations). The segment is skipped and
      // the connection may remain unrouted. This is non-critical — other segments will continue.
      FRLogger.warn(
          "A trace segment could not be normalized and was skipped. "
              + "Affected net may have an unrouted connection. Cause: "
              + e.getMessage());
      FRLogger.debug("BasicBoard.insert_trace_segment: normalization exception detail: " + e);
    }
  }

  /**
   * Inserts a trace into the board, whose geometry is described by an array of points, and cleans
   * up the net.
   */
  public void insertTrace(
      Point[] points,
      int layer,
      int halfWidth,
      int[] netNumbers,
      int clearanceClassIndex,
      FixedState fixedState) {
    for (int i = 0; i < points.length; i++) {
      if (!this.boundingBox.contains(points[i])) {
        FRLogger.warn("LayeredBoard.insert_trace: input point out of range");
      }
    }
    Polyline poly = new Polyline(points);
    insertTrace(poly, layer, halfWidth, netNumbers, clearanceClassIndex, fixedState);
  }

  /**
   * Inserts a via into the board. attachAllowed indicates, if the via may overlap with smd pins of
   * the same net.
   */
  public Via insertVia(
      Padstack padstack,
      Point center,
      int[] netNumbers,
      int clearanceClassIndex,
      FixedState fixedState,
      boolean attachAllowed) {
    Via newVia =
        new Via(
            padstack,
            center,
            netNumbers,
            clearanceClassIndex,
            0,
            0,
            fixedState,
            attachAllowed,
            this);
    insertItem(newVia);
    int fromLayer = padstack.fromLayer();
    int toLayer = padstack.toLayer();
    for (int i = fromLayer; i < toLayer; i++) {
      for (int currentNetNumber : netNumbers) {
        splitTraces(center, i, currentNetNumber);
      }
    }
    return newVia;
  }

  /**
   * Inserts a special escape via into the board for the fanout escalation phase. An escape via sits
   * directly on top of an SMD pin to provide a layer transition to an inner routing layer. On the
   * SMD layer it uses SMD-to-SMD clearance rules (because its copper is inside the SMD pad
   * footprint); on inner layers it uses normal via clearance.
   *
   * @param padstack The padstack describing the via geometry
   * @param center The center point (at the SMD pin center)
   * @param netNumbers The net numbers
   * @param clearanceClassIndex The clearance class index to use
   * @param fixedState The fixed state
   * @param smdLayer The SMD layer where the pin lives (clearance exception layer)
   */
  public Via insertEscapeVia(
      Padstack padstack,
      Point center,
      int[] netNumbers,
      int clearanceClassIndex,
      FixedState fixedState,
      int smdLayer) {
    Via newVia =
        new Via(padstack, center, netNumbers, clearanceClassIndex, 0, 0, fixedState, true, this);
    newVia.isEscapeVia = true;
    newVia.escapeViaSmdLayer = smdLayer;
    insertItem(newVia);
    int fromLayer = padstack.fromLayer();
    int toLayer = padstack.toLayer();
    for (int i = fromLayer; i <= toLayer; i++) {
      for (int currentNetNumber : netNumbers) {
        splitTraces(center, i, currentNetNumber);
      }
    }
    return newVia;
  }

  /**
   * Inserts a pin into the board. pinIndex is the index of this pin in the library package of its
   * component (starting with 0).
   */
  public Pin insertPin(
      int componentId,
      int pinIndex,
      int[] netNumbers,
      int clearanceClassIndex,
      FixedState fixedState) {
    Pin newPin =
        new Pin(componentId, pinIndex, netNumbers, clearanceClassIndex, 0, fixedState, this);
    insertItem(newPin);
    return newPin;
  }

  /**
   * Inserts an obstacle into the board , whose geometry is described by a polygonal shape, which
   * may have holes. If componentNo != 0, the obstacle belongs to a component.
   */
  public ObstacleArea insertObstacle(
      Area area, int layer, int clearanceClassIndex, FixedState fixedState) {
    if (area == null) {
      FRLogger.warn("BasicBoard.insert_obstacle: area is null");
      return null;
    }
    ObstacleArea obs =
        new ObstacleArea(
            area, layer, Vector.ZERO, 0, false, clearanceClassIndex, 0, 0, null, fixedState, this);
    insertItem(obs);
    return obs;
  }

  /**
   * Inserts an obstacle belonging to a component into the board name is to identify the
   * corresponding ObstacleArea in the component package.
   */
  public ObstacleArea insertObstacle(
      Area area,
      int layer,
      Vector translation,
      double rotationInDegree,
      boolean sideChanged,
      int clearanceClassIndex,
      int componentId,
      String name,
      FixedState fixedState) {
    if (area == null) {
      FRLogger.warn("BasicBoard.insert_obstacle: area is null");
      return null;
    }
    ObstacleArea obs =
        new ObstacleArea(
            area,
            layer,
            translation,
            rotationInDegree,
            sideChanged,
            clearanceClassIndex,
            0,
            componentId,
            name,
            fixedState,
            this);
    insertItem(obs);
    return obs;
  }

  /**
   * Inserts a via obstacle area into the board , whose geometry is described by a polygonal shape,
   * which may have holes.
   */
  public ViaObstacleArea insertViaObstacle(
      Area area, int layer, int clearanceClassIndex, FixedState fixedState) {
    if (area == null) {
      FRLogger.warn("BasicBoard.insert_via_obstacle: area is null");
      return null;
    }
    ViaObstacleArea obs =
        new ViaObstacleArea(
            area, layer, Vector.ZERO, 0, false, clearanceClassIndex, 0, 0, null, fixedState, this);
    insertItem(obs);
    return obs;
  }

  /**
   * Inserts a via obstacle belonging to a component into the board name is to identify the
   * corresponding ObstacleArea in the component package.
   */
  public ViaObstacleArea insertViaObstacle(
      Area area,
      int layer,
      Vector translation,
      double rotationInDegree,
      boolean sideChanged,
      int clearanceClassIndex,
      int componentId,
      String name,
      FixedState fixedState) {
    if (area == null) {
      FRLogger.warn("BasicBoard.insert_via_obstacle: area is null");
      return null;
    }
    ViaObstacleArea obs =
        new ViaObstacleArea(
            area,
            layer,
            translation,
            rotationInDegree,
            sideChanged,
            clearanceClassIndex,
            0,
            componentId,
            name,
            fixedState,
            this);
    insertItem(obs);
    return obs;
  }

  /**
   * Inserts a component obstacle area into the board , whose geometry is described by a polygonal
   * shape, which may have holes.
   */
  public ComponentObstacleArea insertComponentObstacle(
      Area area, int layer, int clearanceClassIndex, FixedState fixedState) {
    if (area == null) {
      FRLogger.warn("BasicBoard.insert_component_obstacle: area is null");
      return null;
    }
    ComponentObstacleArea obs =
        new ComponentObstacleArea(
            area, layer, Vector.ZERO, 0, false, clearanceClassIndex, 0, 0, null, fixedState, this);
    insertItem(obs);
    return obs;
  }

  /**
   * Inserts a component obstacle belonging to a component into the board. name is to identify the
   * corresponding ObstacleArea in the component package.
   */
  public ComponentObstacleArea insertComponentObstacle(
      Area area,
      int layer,
      Vector translation,
      double rotationInDegree,
      boolean sideChanged,
      int clearanceClassIndex,
      int componentId,
      String name,
      FixedState fixedState) {
    if (area == null) {
      FRLogger.warn("BasicBoard.insert_component_obstacle: area is null");
      return null;
    }
    ComponentObstacleArea obs =
        new ComponentObstacleArea(
            area,
            layer,
            translation,
            rotationInDegree,
            sideChanged,
            clearanceClassIndex,
            0,
            componentId,
            name,
            fixedState,
            this);
    insertItem(obs);
    return obs;
  }

  /** Inserts a component outline into the board. */
  public ComponentOutline insertComponentOutline(
      Area area,
      boolean isFront,
      Vector translation,
      double rotationInDegree,
      int componentId,
      boolean isCourtyard,
      boolean isFabrication,
      boolean isClosed,
      FixedState fixedState) {
    if (area == null) {
      FRLogger.warn("BasicBoard.insert_component_outline: area is null");
      return null;
    }
    if (!area.isBounded()) {
      FRLogger.warn("BasicBoard.insert_component_outline: area is not bounded");
      return null;
    }
    ComponentOutline outline =
        new ComponentOutline(
            area,
            isFront,
            translation,
            rotationInDegree,
            0,
            componentId,
            isCourtyard,
            isFabrication,
            isClosed,
            fixedState,
            this);
    insertItem(outline);
    return outline;
  }

  /**
   * Inserts a conduction area into the board , whose geometry is described by a polygonal shape,
   * which may have holes. If isObstacle is false, it is possible to route through the conduction
   * area with traces and vias of foreign nets.
   */
  public ConductionArea insertConductionArea(
      Area area,
      int layer,
      int[] netNumbers,
      int clearanceClassIndex,
      boolean isObstacle,
      FixedState fixedState) {
    if (area == null) {
      FRLogger.warn("BasicBoard.insert_conduction_area: area is null");
      return null;
    }
    ConductionArea c =
        new ConductionArea(
            area,
            layer,
            Vector.ZERO,
            0,
            false,
            netNumbers,
            clearanceClassIndex,
            0,
            0,
            null,
            isObstacle,
            fixedState,
            this);
    insertItem(c);
    return c;
  }

  /** Inserts an Outline into the board. */
  public BoardOutline insertOutline(PolylineShape[] outlineShapes, int clearanceClassIndex) {
    BoardOutline result = new BoardOutline(outlineShapes, clearanceClassIndex, 0, this);
    insertItem(result);
    return result;
  }

  /**
   * Expands the board's bounding box so that all placed items (pins, obstacles, conduction areas)
   * are fully contained within the routable bounding box, with a minimum margin.
   */
  public void expandBoundingBoxToIncludeAllItems() {
    IntBox bounds = this.boundingBox;
    boolean changed = false;
    for (Item item : getItems()) {
      IntBox itemBox = item.boundingBox();
      if (itemBox != null && !itemBox.isEmpty() && !bounds.contains(itemBox)) {
        bounds = bounds.union(itemBox);
        changed = true;
      }
    }
    if (changed) {
      this.boundingBox = bounds.offset(1000);
      BoardOutline outline = getOutline();
      if (outline != null) {
        outline.invalidateEdgePinNets();
      }
    }
  }

  /** Returns the outline of the board. */
  public BoardOutline getOutline() {
    return getItemRepository().getOutline();
  }

  /** Drops the outline's cached edge-pin net set after a pin or outline mutation. */
  public void invalidateEdgePinNetCache() {
    BoardOutline outline = getOutline();
    if (outline != null) {
      outline.invalidateEdgePinNets();
    }
  }

  /** Removes an item from the board. */
  public void removeItem(Item item) {
    getItemRepository().removeItem(item);
    if (item instanceof Pin || item instanceof BoardOutline) {
      BoardOutline outline = getOutline();
      if (outline != null) {
        outline.invalidateEdgePinNets();
      }
    }
  }

  /**
   * Searches for an item with the specified ID on the board.
   *
   * @param id the ID of the item to search for
   * @return the found item, or null if no such item is found
   */
  public Item getItem(int id) {
    return getItemRepository().getItem(id);
  }

  /** Returns the list of all items on the board. */
  public Collection<Item> getItems() {
    return getItemRepository().getItems();
  }

  /** Returns all connectable items on the board containing netNumber. */
  public Collection<Item> getConnectableItems(int netNumber) {
    return getConnectivityQueries().getConnectableItems(netNumber);
  }

  /** Returns the count of connectable items of the net with number netNumber. */
  public int connectableItemCount(int netNumber) {
    return getConnectivityQueries().connectableItemCount(netNumber);
  }

  /** Returns all items with the input component ID. */
  public Collection<Item> getComponentItems(int componentId) {
    return getConnectivityQueries().getComponentItems(componentId);
  }

  /** Returns all pins with the input component ID. */
  public Collection<Pin> getComponentPins(int componentId) {
    return getConnectivityQueries().getComponentPins(componentId);
  }

  /** Returns the pin with the input component ID and pin index, or null, if no such pin exists. */
  public Pin getPin(int componentId, int pinIndex) {
    return getConnectivityQueries().getPin(componentId, pinIndex);
  }

  /**
   * Removes the items in itemList. Returns false, if some items could not be removed, because they
   * are fixed.
   */
  public boolean removeItems(Collection<Item> itemList) {
    boolean result = true;
    for (Item currentItem : itemList) {
      if (currentItem.isDeletionForbidden() || currentItem.isUserFixed()) {
        // We are not allowed to delete this item
        result = false;
      } else {
        removeItem(currentItem);
      }
    }
    return result;
  }

  /** Returns the list of all conduction areas on the board. */
  public Collection<ConductionArea> getConductionAreas() {
    return getItemRepository().getConductionAreas();
  }

  /** Returns the list of all pins on the board. */
  public Collection<Pin> getPins() {
    return getItemRepository().getPins();
  }

  /** Returns the list of all pins on the board with only 1 layer. */
  public Collection<Pin> getSmdPins() {
    return getItemRepository().getSmdPins();
  }

  /** Returns the list of all vias on the board. */
  public Collection<Via> getVias() {
    return getItemRepository().getVias();
  }

  /** Returns the list of all traces on the board. */
  public Collection<Trace> getTraces() {
    return getItemRepository().getTraces();
  }

  /** Returns the cumulative length of all traces on the board. */
  public double cumulativeTraceLength() {
    return getItemRepository().cumulativeTraceLength();
  }

  /**
   * Combines the connected traces of this net, which have only 1 contact at the connection point.
   * if netNumber {@literal <} 0 traces of all nets are combined.
   */
  public boolean combineTraces(int netNumber) {
    boolean result = false;
    boolean somethingChanged = true;
    while (somethingChanged) {
      somethingChanged = false;
      Iterator<UndoableObjects.UndoableObjectNode> it = itemList.startReadObject();
      for (; ; ) {
        Item currentItem = (Item) itemList.readObject(it);
        if (currentItem == null) {
          break;
        }
        if ((netNumber < 0 || currentItem.containsNet(netNumber))
            && currentItem instanceof Trace trace
            && currentItem.isOnTheBoard()) {
          if (trace.combine()) {
            somethingChanged = true;
            result = true;
            break;
          }
        }
      }
    }
    return result;
  }

  /** Normalizes the traces of this net. */
  public boolean normalizeTraces(int netNumber) {
    if (normalizeSuppressedNetNos == null) {
      normalizeSuppressedNetNos = new HashSet<>();
    }
    if (normalizeSuppressedNetNos.contains(netNumber)) {
      String netName =
          rules != null && rules.nets != null && rules.nets.get(netNumber) != null
              ? rules.nets.get(netNumber).name
              : String.valueOf(netNumber);
      FRLogger.debug(
          "BasicBoard.normalizeTraces: skipping net '"
              + netName
              + "' because normalization already hit the oscillation cap on this board candidate.");
      return false;
    }
    boolean result = false;
    boolean somethingChanged = true;
    int iterationCount = 0;
    while (somethingChanged) {
      if (++iterationCount > MAX_NORMALIZE_ITERATIONS) {
        // Safety valve: after this many passes the outer loop has not converged.
        // This can happen when a pair of traces keeps oscillating between a split state
        // and a re-combined state (e.g. a self-intersecting or zero-length segment that
        // the geometry engine cannot cleanly normalise).  Stop here rather than hanging
        // the board-load thread for minutes.
        String netName =
            rules != null && rules.nets != null && rules.nets.get(netNumber) != null
                ? rules.nets.get(netNumber).name
                : String.valueOf(netNumber);
        FRLogger.warn(
            "BasicBoard.normalizeTraces: reached "
                + MAX_NORMALIZE_ITERATIONS
                + " iterations for net '"
                + netName
                + "' — stopping to prevent hang."
                + " The board geometry for this net may be oscillating (split/combine cycle);"
                + " traces are kept as-is and further normalization for this net is suppressed"
                + " on this board candidate.");
        normalizeSuppressedNetNos.add(netNumber);
        break;
      }
      somethingChanged = false;

      // Collect traces for this net on this iteration to avoid ConcurrentModificationException
      // on the board's itemList during iteration, and to avoid scanning the entire board
      // repeatedly.
      java.util.List<PolylineTrace> netTraces = new java.util.ArrayList<>();
      Iterator<UndoableObjects.UndoableObjectNode> it = itemList.startReadObject();
      for (; ; ) {
        Item currentItem;
        try {
          currentItem = (Item) itemList.readObject(it);
        } catch (ConcurrentModificationException _) {
          // If the board's item list was modified during collection (should be rare during
          // collection itself),
          // set somethingChanged to true to retry from a fresh state.
          somethingChanged = true;
          break;
        }
        if (currentItem == null) {
          break;
        }
        if (currentItem.containsNet(netNumber)
            && currentItem instanceof PolylineTrace currentTrace
            && currentItem.isOnTheBoard()) {
          netTraces.add(currentTrace);
        }
      }

      if (somethingChanged) {
        continue;
      }

      for (PolylineTrace currentTrace : netTraces) {
        if (currentTrace.isOnTheBoard()) {
          if (currentTrace.normalize(null)) {
            somethingChanged = true;
            result = true;
          } else if (!currentTrace.isUserFixed() && this.removeIfCycle(currentTrace)) {
            somethingChanged = true;
            result = true;
          }
        }
      }
    }
    return result;
  }

  /** Normalizes the traces of all nets on the board in a single optimized pass. */
  public boolean normalizeAllTraces() {
    boolean result = false;
    // Group all PolylineTrace items by net
    java.util.Map<Integer, java.util.List<PolylineTrace>> tracesByNet = new java.util.HashMap<>();
    Iterator<UndoableObjects.UndoableObjectNode> it = itemList.startReadObject();
    for (; ; ) {
      Item currentItem;
      try {
        currentItem = (Item) itemList.readObject(it);
      } catch (java.util.ConcurrentModificationException _) {
        // Retry collection if modified
        tracesByNet.clear();
        it = itemList.startReadObject();
        continue;
      }
      if (currentItem == null) {
        break;
      }
      if (currentItem instanceof PolylineTrace currentTrace && currentItem.isOnTheBoard()) {
        for (int netNumber : currentTrace.netNumbers) {
          tracesByNet
              .computeIfAbsent(netNumber, k -> new java.util.ArrayList<>())
              .add(currentTrace);
        }
      }
    }

    for (java.util.Map.Entry<Integer, java.util.List<PolylineTrace>> entry :
        tracesByNet.entrySet()) {
      int netNumber = entry.getKey();
      java.util.List<PolylineTrace> netTraces = entry.getValue();
      boolean somethingChanged = true;
      int iterationCount = 0;
      while (somethingChanged) {
        if (++iterationCount > MAX_NORMALIZE_ITERATIONS) {
          String netName =
              rules != null && rules.nets != null && rules.nets.get(netNumber) != null
                  ? rules.nets.get(netNumber).name
                  : String.valueOf(netNumber);
          FRLogger.warn(
              "BasicBoard.normalize_all_traces: reached "
                  + MAX_NORMALIZE_ITERATIONS
                  + " iterations for net '"
                  + netName
                  + "' — stopping to prevent hang.");
          break;
        }
        somethingChanged = false;

        for (PolylineTrace currentTrace : netTraces) {
          if (currentTrace.isOnTheBoard()) {
            if (currentTrace.normalize(null)) {
              somethingChanged = true;
              result = true;
            } else if (!currentTrace.isUserFixed() && this.removeIfCycle(currentTrace)) {
              somethingChanged = true;
              result = true;
            }
          }
        }

        // If something changed, collect the traces for this net again
        if (somethingChanged) {
          netTraces.clear();
          Iterator<UndoableObjects.UndoableObjectNode> it2 = itemList.startReadObject();
          for (; ; ) {
            Item currentItem;
            try {
              currentItem = (Item) itemList.readObject(it2);
            } catch (java.util.ConcurrentModificationException _) {
              netTraces.clear();
              it2 = itemList.startReadObject();
              continue;
            }
            if (currentItem == null) {
              break;
            }
            if (currentItem.containsNet(netNumber)
                && currentItem instanceof PolylineTrace currentTrace
                && currentItem.isOnTheBoard()) {
              netTraces.add(currentTrace);
            }
          }
        }
      }
    }
    return result;
  }

  /**
   * Looks for traces of the input net on the input layer, so that location is on the trace polygon,
   * and splits these traces. Returns false, if no trace was split.
   */
  public boolean splitTraces(Point location, int layer, int netNumber) {
    ItemSelectionFilter filter =
        new ItemSelectionFilter(ItemSelectionFilter.SelectableChoices.TRACES);
    Collection<Item> pickedItems = this.pickItems(location, layer, filter);
    IntOctagon locationShape = TileShape.getInstance(location).boundingOctagon();
    boolean traceSplit = false;
    for (Item currentItem : pickedItems) {
      Trace currentTrace = (Trace) currentItem;
      if (currentTrace.containsNet(netNumber)) {
        Collection<PolylineTrace> splitPieces = currentTrace.split(locationShape);
        if (splitPieces.size() != 1) {
          traceSplit = true;
        }
      }
    }
    return traceSplit;
  }

  /** Returns a Collection of Collections of items forming a connected set. */
  public Collection<Collection<Item>> getConnectedSets(int netNumber) {
    return getConnectivityQueries().getConnectedSets(netNumber);
  }

  /**
   * Returns all SearchTreeObjects on layer layer, which overlap with shape. If layer {@literal <}
   * 0, the layer is ignored
   */
  public Set<SearchTreeObject> overlappingObjects(ConvexShape shape, int layer) {
    return this.searchTreeManager.getDefaultTree().overlappingObjects(shape, layer);
  }

  /**
   * Returns items, which overlap with shape on layer layer inclusive clearance. clearanceClass is
   * the index in the clearance matrix, which describes the required clearance restrictions to other
   * items. The function may also return items, which are nearly overlapping, but do not overlap
   * with exact calculation. If layer {@literal <} 0, the layer is ignored.
   */
  public Set<Item> overlappingItemsWithClearance(
      ConvexShape shape, int layer, int[] ignoreNetNos, int clearanceClass) {
    ShapeSearchTree defaultTree = this.searchTreeManager.getDefaultTree();
    return defaultTree.overlappingItemsWithClearance(shape, layer, ignoreNetNos, clearanceClass);
  }

  /**
   * Returns all items on layer layer, which overlap with area. If layer {@literal <} 0, the layer
   * is ignored
   */
  public Set<Item> overlappingItems(Area area, int layer) {
    Set<Item> result = new TreeSet<>();
    TileShape[] tileShapes = area.splitToConvex();
    for (int i = 0; i < tileShapes.length; i++) {
      Set<SearchTreeObject> currentOverlaps = overlappingObjects(tileShapes[i], layer);
      for (SearchTreeObject currentOverlap : currentOverlaps) {
        if (currentOverlap instanceof Item item) {
          result.add(item);
        }
      }
    }
    return result;
  }

  /**
   * Checks, if an object with shape shape and net nos netNumbers and clearance class
   * clearanceClassIndex can be inserted on layer layer without clearance violation.
   */
  public boolean checkShape(Area shape, int layer, int[] netNumbers, int clearanceClassIndex) {
    TileShape[] tiles = shape.splitToConvex();
    ShapeSearchTree defaultTree = this.searchTreeManager.getDefaultTree();
    for (int i = 0; i < tiles.length; i++) {
      TileShape currentShape = tiles[i];
      if (!currentShape.isContainedIn(boundingBox)) {
        return false;
      }
      Set<SearchTreeObject> obstacles = new TreeSet<>();
      defaultTree.overlappingObjectsWithClearance(
          currentShape, layer, netNumbers, clearanceClassIndex, obstacles);
      for (SearchTreeObject currentObject : obstacles) {
        boolean isObstacle = true;
        for (int j = 0; j < netNumbers.length; j++) {
          if (!currentObject.isObstacle(netNumbers[j])) {
            isObstacle = false;
          }
        }
        if (isObstacle) {
          return false;
        }
      }
    }
    return true;
  }

  /**
   * Checks, if a trace line with shape shape and net numbers netNumbers and clearance class
   * clearanceClassIndex can be inserted on layer layer without clearance violation. If contactPins
   * != null, all pins not contained in contactPins are regarded as obstacles, even if they are of
   * the own net.
   */
  public boolean checkTraceShape(
      TileShape shape, int layer, int[] netNumbers, int clearanceClassIndex, Set<Pin> contactPins) {
    if (!shape.isContainedIn(boundingBox)) {
      return false;
    }
    ShapeSearchTree defaultTree = this.searchTreeManager.getDefaultTree();
    Collection<TreeEntry> treeEntries = new LinkedList<>();
    int[] ignoreNetNos = new int[0];
    if (defaultTree.isClearanceCompensationUsed()) {
      defaultTree.overlappingTreeEntries(shape, layer, ignoreNetNos, treeEntries);
    } else {
      defaultTree.overlappingTreeEntriesWithClearance(
          shape, layer, ignoreNetNos, clearanceClassIndex, treeEntries);
    }
    for (TreeEntry currentTreeEntry : treeEntries) {
      if (!(currentTreeEntry.object instanceof Item currentItem)) {
        continue;
      }
      if (contactPins != null) {
        if (contactPins.contains(currentItem)) {
          continue;
        }
        if (currentItem instanceof Pin) {
          // The contact pins of the trace should be contained in ignoreItems.
          // Other pins are handled as obstacles to avoid acid traps.
          return false;
        }
      }
      boolean isObstacle = true;
      for (int i = 0; i < netNumbers.length; i++) {
        if (!currentItem.isTraceObstacle(netNumbers[i])) {
          isObstacle = false;
        }
      }
      if (isObstacle && (currentItem instanceof PolylineTrace) && contactPins != null) {
        // check for traces of foreign nets at tie pins, which will be ignored inside
        // the pin shape
        TileShape intersection = null;
        for (Pin currentContactPin : contactPins) {
          if (currentContactPin.netCount() <= 1 || !currentContactPin.sharesNet(currentItem)) {
            continue;
          }
          if (intersection == null) {
            TileShape obstacleTraceShape =
                currentItem.getTileShape(currentTreeEntry.shapeIndexInObject);
            intersection = shape.intersection(obstacleTraceShape);
          }
          TileShape pinShape = currentContactPin.getTileShapeOnLayer(layer);
          if (pinShape.containsApprox(intersection)) {
            isObstacle = false;
            break;
          }
        }
      }
      if (isObstacle) {
        return false;
      }
    }
    return true;
  }

  /**
   * Checks, if a polyline trace with the input parameters can be inserted without clearance
   * violations.
   */
  public boolean checkPolylineTrace(
      Polyline polyline, int layer, int penHalfWidth, int[] netNumbers, int clearanceClassIndex) {
    Trace tmpTrace =
        new PolylineTrace(
            polyline,
            layer,
            penHalfWidth,
            netNumbers,
            clearanceClassIndex,
            0,
            0,
            FixedState.UNFIXED,
            this);
    Set<Pin> contactPins = tmpTrace.touchingPinsAtEndCorners();
    for (int i = 0; i < tmpTrace.tileShapeCount(); i++) {
      if (!this.checkTraceShape(
          tmpTrace.getTileShape(i), layer, netNumbers, clearanceClassIndex, contactPins)) {
        return false;
      }
    }
    return true;
  }

  /** Returns the layer count of this board. */
  public int getLayerCount() {
    return layerStructure.layers.length;
  }

  /**
   * Returns the list of items on the board, whose shape on layer layer contains the point at
   * location. If layer {@literal <} 0, the layer is ignored. If itemSelectionFilter != null, only
   * items of types selected by the filter are picked.
   */
  public Set<Item> pickItems(Point location, int layer, ItemSelectionFilter filter) {
    TileShape pointShape = TileShape.getInstance(location);
    Collection<SearchTreeObject> overlaps = overlappingObjects(pointShape, layer);
    Set<Item> result = new TreeSet<>();
    for (SearchTreeObject currentObject : overlaps) {
      if (currentObject instanceof Item item) {
        result.add(item);
      }
    }
    if (filter != null) {
      result = filter.filter(result);
    }
    return result;
  }

  /** Checks, if point is contained in the bounding box of this board. */
  public boolean contains(Point point) {
    return point.isContainedIn(boundingBox);
  }

  /**
   * Returns the minimum clearance requested between items of clearance class class1 and class2.
   * class1 and class2 are indices in the clearance matrix.
   */
  public int clearanceValue(int class1, int class2, int layer) {
    if (rules == null || rules.clearanceMatrix == null) {
      return 0;
    }
    return rules.clearanceMatrix.getValue(class1, class2, layer, true);
  }

  /** Returns the biggest half width of all traces on the board. */
  public int getMaxTraceHalfWidth() {
    return maxTraceHalfWidth;
  }

  /** Returns the smallest half width of all traces on the board. */
  public int getMinTraceHalfWidth() {
    return minTraceHalfWidth;
  }

  /** Returns a surrounding box of the geometry of this board. */
  public IntBox getBoundingBox() {
    return boundingBox;
  }

  /** Returns a box containing all items in itemList. */
  public IntBox getBoundingBox(Collection<Item> itemList) {
    IntBox result = IntBox.EMPTY;
    for (Item currentItem : itemList) {
      result = result.union(currentItem.boundingBox());
    }
    return result;
  }

  /** Resets the rectangle, where a graphics update is needed. */
  public void resetGraphicsUpdateBox() {
    updateBox = IntBox.EMPTY;
  }

  /** Gets the rectangle, where a graphics update is needed on the screen. */
  public IntBox getGraphicsUpdateBox() {
    return updateBox;
  }

  /** Enlarges the graphics update box, so that it contains box. */
  public void joinGraphicsUpdateBox(IntBox box) {
    if (updateBox == null) {
      resetGraphicsUpdateBox();
    }
    updateBox = updateBox.union(box);
  }

  /** Starts notifying the observers of any change in the objects list. */
  public void startNotifyObservers() {
    if ((communication != null) && (this.communication.observers != null)) {
      communication.observers.activate();
    }
  }

  /** Ends notifying the observers of changes in the objects list. */
  public void endNotifyObservers() {
    if ((communication != null) && (this.communication.observers != null)) {
      communication.observers.deactivate();
    }
  }

  /** Returns, if the observer of the board items is activated. */
  public boolean observersActive() {
    boolean result;
    if ((communication != null) && (this.communication.observers != null)) {
      result = communication.observers.isActive();
    } else {
      result = false;
    }
    return result;
  }

  /**
   * Turns an obstacle area into a conduction area with net number netNumber If it is convex and has
   * no holes, it is turned into a Pin, else into a conduction area.
   */
  public Connectable makeConductive(ObstacleArea area, int netNumber) {
    Item newItem;
    Area currentArea = area.getRelativeArea();
    int layer = area.getLayer();
    FixedState fixedState = area.getFixedState();
    Vector translation = area.getTranslation();
    double rotation = area.getRotationInDegree();
    boolean sideChanged = area.getSideChanged();
    int[] netNumbers = new int[1];
    netNumbers[0] = netNumber;
    newItem =
        new ConductionArea(
            currentArea,
            layer,
            translation,
            rotation,
            sideChanged,
            netNumbers,
            area.clearanceClassIndex(),
            0,
            area.getComponentId(),
            area.name,
            true,
            fixedState,
            this);
    removeItem(area);
    insertItem(newItem);
    return (Connectable) newItem;
  }

  /** Inserts an item into the board database. */
  public void insertItem(Item item) {
    getItemRepository().insertItem(item);
    if (item instanceof Pin || item instanceof BoardOutline) {
      BoardOutline outline = getOutline();
      if (outline != null) {
        outline.invalidateEdgePinNets();
      }
    }
  }

  /**
   * Stub function overwritten in class RoutingBoard to maintain the autorouter database if
   * necessary.
   */
  public void additionalUpdateAfterChange(Item item) {}

  /**
   * Restores the situation at the previous snapshot. Returns false, if no more undo is possible.
   * Puts the numbers of the changed nets into the set changedNets, if changedNets != null
   */
  public boolean undo(Set<Integer> changedNets) {
    this.components.undo(this.communication.observers);
    Collection<UndoableObjects.Storable> cancelledObjects = new LinkedList<>();
    Collection<UndoableObjects.Storable> restoredObjects = new LinkedList<>();
    boolean result = itemList.undo(cancelledObjects, restoredObjects);
    applyUndoRedoSideEffects(cancelledObjects, restoredObjects, changedNets);
    return result;
  }

  /**
   * Restores the situation before the last undo. Returns false, if no more redo is possible. Puts
   * the numbers of the changed nets into the set changedNets, if changedNets != null
   */
  public boolean redo(Set<Integer> changedNets) {
    this.components.redo(this.communication.observers);
    Collection<UndoableObjects.Storable> cancelledObjects = new LinkedList<>();
    Collection<UndoableObjects.Storable> restoredObjects = new LinkedList<>();
    boolean result = itemList.redo(cancelledObjects, restoredObjects);
    applyUndoRedoSideEffects(cancelledObjects, restoredObjects, changedNets);
    return result;
  }

  private void applyUndoRedoSideEffects(
      Collection<UndoableObjects.Storable> cancelledObjects,
      Collection<UndoableObjects.Storable> restoredObjects,
      Set<Integer> changedNets) {
    Iterator<UndoableObjects.Storable> it = cancelledObjects.iterator();
    while (it.hasNext()) {
      Item currentItem = (Item) it.next();
      searchTreeManager.remove(currentItem);
      if ((communication != null) && (communication.observers != null)) {
        communication.observers.notifyDeleted(currentItem);
      }
      if (changedNets != null) {
        for (int i = 0; i < currentItem.netCount(); i++) {
          changedNets.add(currentItem.getNetNumber(i));
        }
      }
    }
    it = restoredObjects.iterator();
    while (it.hasNext()) {
      Item currentItem = (Item) it.next();
      currentItem.board = this;
      searchTreeManager.insert(currentItem);
      currentItem.clearAutorouteInfo();
      if ((communication != null) && (communication.observers != null)) {
        communication.observers.notifyNew(currentItem);
      }
      if (changedNets != null) {
        for (int i = 0; i < currentItem.netCount(); i++) {
          changedNets.add(currentItem.getNetNumber(i));
        }
      }
    }
    invalidateEdgePinNetCache();
  }

  /** Makes the current board situation restorable by undo. */
  public void generateSnapshot() {
    getSnapshotManager().generateSnapshot();
  }

  /**
   * Removes the top snapshot from the undo stack, so that its situation cannot be restored anymore.
   * Returns false, if no more snapshot could be popped.
   */
  public boolean popSnapshot() {
    return getSnapshotManager().popSnapshot();
  }

  /**
   * Looks if at the input position ends a trace with the input net number, which has no normal
   * contact at that position. Returns null, if no tail is found.
   */
  public Trace getTraceTail(Point location, int layer, int[] netNumbers) {
    TileShape pointShape = TileShape.getInstance(location);
    Collection<SearchTreeObject> foundItems = overlappingObjects(pointShape, layer);
    for (SearchTreeObject currentObject : foundItems) {
      if (currentObject instanceof Trace currentTrace) {
        if (!currentTrace.netsEqual(netNumbers)) {
          continue;
        }
        if (currentTrace.firstCorner().equals(location)) {
          Collection<Item> contacts = currentTrace.getStartContacts();
          if (contacts.isEmpty()) {
            return currentTrace;
          }
        }
        if (currentTrace.lastCorner().equals(location)) {
          Collection<Item> contacts = currentTrace.getEndContacts();
          if (contacts.isEmpty()) {
            return currentTrace;
          }
        }
      }
    }
    return null;
  }

  /**
   * Checks, if item item is part of a cycle and remove it together with its connection in this
   * case.
   */
  public boolean removeIfCycle(Trace trace) {
    if (!trace.isOnTheBoard()) {
      return false;
    }
    if (!trace.isCycle()) {
      return false;
    }
    // Remove tails at the endpoints after removing the cycle,
    // if there was no tail before.
    int currentLayer = trace.getLayer();
    int[] currentNetNumbers = trace.netNumbers;
    Point[] endCorners = new Point[2];
    endCorners[0] = trace.firstCorner();
    endCorners[1] = trace.lastCorner();
    boolean[] tailAtEndpointBefore = new boolean[2];
    for (int i = 0; i < 2; i++) {
      Trace tail = getTraceTail(endCorners[i], currentLayer, currentNetNumbers);
      tailAtEndpointBefore[i] = tail != null;
    }
    Set<Item> connectionItems = trace.getConnectionItems();
    this.removeItems(connectionItems);
    for (int i = 0; i < 2; i++) {
      if (!tailAtEndpointBefore[i]) {
        Trace tail = getTraceTail(endCorners[i], currentLayer, currentNetNumbers);
        if (tail != null) {
          removeItems(tail.getConnectionItems());
        }
      }
    }
    return true;
  }

  private BoardItemRepository getItemRepository() {
    if (itemRepository == null) {
      itemRepository = new BoardItemRepository(this);
    }
    return itemRepository;
  }

  private BoardConnectivityQueries getConnectivityQueries() {
    if (connectivityQueries == null) {
      connectivityQueries = new BoardConnectivityQueries(this);
    }
    return connectivityQueries;
  }

  private BoardSnapshotManager getSnapshotManager() {
    if (snapshotManager == null) {
      snapshotManager = new BoardSnapshotManager(this);
    }
    return snapshotManager;
  }

  private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
    stream.defaultReadObject();
    // insert the items on the board into the search trees
    searchTreeManager = new SearchTreeManager(this);
    normalizeSuppressedNetNos = new HashSet<>();
    itemRepository = null;
    connectivityQueries = null;
    snapshotManager = null;
    for (Item currentItem : this.getItems()) {
      currentItem.board = this;
      searchTreeManager.insert(currentItem);
    }
  }

  /** Deletes all traces and vias from the board. */
  public void deleteAllTracksAndVias() {
    Iterator<UndoableObjects.UndoableObjectNode> it = itemList.startReadObject();
    for (; ; ) {
      UndoableObjects.Storable currentItem = itemList.readObject(it);
      if (currentItem == null) {
        break;
      }
      if (currentItem instanceof Trace) {
        // delete the trace
        itemList.delete(currentItem);
      }
      if (currentItem instanceof Via) {
        // delete the via
        itemList.delete(currentItem);
      }
    }
  }

  /**
   * Unfills all conduction zones on the board, leaving only their definitions (boundaries) visible.
   * This disables them as routing obstacles and prevents connection stubs from being routed to
   * them.
   */
  public void unfillConductionAreas() {
    this.rules.setIgnoreConduction(true);
    Iterator<UndoableObjects.UndoableObjectNode> it = itemList.startReadObject();
    for (; ; ) {
      UndoableObjects.Storable currentItem = itemList.readObject(it);
      if (currentItem == null) {
        break;
      }
      if (currentItem instanceof ConductionArea currentConductionArea) {
        currentConductionArea.setIsFilled(false);
        currentConductionArea.setIsObstacle(false);
      }
    }
    this.searchTreeManager.reinsertTreeItems();
  }

  /** Logs a warning if connectable items exist on inactive routing layers. */
  public void areThereItemsOnInactiveLayer(AutorouteControl ctrl) {
    if (this.getLayerCount() > 2) {
      boolean hasSomethingOnInactiveLayer = false;
      Iterator<UndoableObjects.UndoableObjectNode> it = this.itemList.startReadObject();
      for (; ; ) {
        UndoableObjects.Storable currentObject = this.itemList.readObject(it);
        if (currentObject == null) {
          break;
        }
        if (currentObject instanceof PolylineTrace currentItem) {
          // This is a connectable item, like PolylineTrace or Pin
          if (!ctrl.layerActive[currentItem.getLayer()]) {
            hasSomethingOnInactiveLayer = true;
            FRLogger.warn("There is an item on an inactive layer.");
            break;
          }
        }
      }
    }
  }

  /** Returns the number of traces that are not multiples of 45 degrees. */
  public int getNon45DegreeTraceCount() {
    int count = 0;
    for (Item currentObject : getItems()) {
      if (currentObject instanceof PolylineTrace currentTrace) {
        if (!currentTrace.polyline().isMultipleOf45Degree()) {
          ++count;
        }
      }
    }
    return count;
  }

  /**
   * Waits for any asynchronous post-load processing (such as initial DRC scans) to complete before
   * accessing or mutating board data.
   */
  public void awaitPostLoad() {
    if (this.postLoadFuture != null) {
      try {
        this.postLoadFuture.join();
      } catch (Exception e) {
        FRLogger.warn("Exception while waiting for post-load processing: " + e.getMessage());
      }
    }
  }

  /**
   * Draws all items of the board on their visible layers. Called in the overwritten paintComponent
   * method of a class derived from JPanel. The value of layerVisibility is expected between 0 and 1
   * for each layer.
   */
  public enum DominantSide {
    FRONT,
    BACK,
    NONE
  }
}
