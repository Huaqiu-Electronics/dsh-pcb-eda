package app.freerouting.io.kicad;

import app.freerouting.board.actions.ItemIdGenerator;
import app.freerouting.board.facade.RoutingBoard;
import app.freerouting.board.model.structure.AngleRestriction;
import app.freerouting.board.model.structure.Component;
import app.freerouting.board.model.structure.FixedState;
import app.freerouting.board.model.structure.Layer;
import app.freerouting.board.model.structure.LayerStructure;
import app.freerouting.board.model.structure.Unit;
import app.freerouting.board.state.BoardObserverAdaptor;
import app.freerouting.board.state.BoardObservers;
import app.freerouting.board.state.Communication;
import app.freerouting.core.library.Package;
import app.freerouting.core.library.Packages;
import app.freerouting.core.library.Padstack;
import app.freerouting.core.library.Padstacks;
import app.freerouting.datastructures.IdGenerator;
import app.freerouting.geometry.planar.Area;
import app.freerouting.geometry.planar.Circle;
import app.freerouting.geometry.planar.ConvexShape;
import app.freerouting.geometry.planar.FloatPoint;
import app.freerouting.geometry.planar.IntBox;
import app.freerouting.geometry.planar.IntOctagon;
import app.freerouting.geometry.planar.IntPoint;
import app.freerouting.geometry.planar.IntVector;
import app.freerouting.geometry.planar.Point;
import app.freerouting.geometry.planar.PolygonShape;
import app.freerouting.geometry.planar.PolylineShape;
import app.freerouting.io.BoardMetadata;
import app.freerouting.io.BoardReadResult;
import app.freerouting.io.CoordinateTransform;
import app.freerouting.io.KiCadNetClassNames;
import app.freerouting.logger.FRLogger;
import app.freerouting.rules.BoardRules;
import app.freerouting.rules.ClearanceMatrix;
import app.freerouting.rules.DefaultItemClearanceClasses;
import app.freerouting.rules.Net;
import app.freerouting.rules.NetClass;
import app.freerouting.rules.ViaInfo;
import app.freerouting.rules.ViaRule;
import app.freerouting.util.gson.GsonProvider;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Reads a KiCad board representation from JSON and constructs a fully populated {@link
 * RoutingBoard}.
 */
public final class KiCadJsonReader {

  public static final String BOARD_EDGE_CLEARANCE_CLASS_NAME = "board_edge";

  private KiCadJsonReader() {}

  /**
   * Reads a KiCad JSON structure and returns a fully constructed RoutingBoard wrapped in
   * BoardReadResult.
   */
  public static BoardReadResult readBoard(
      Reader reader, BoardObservers observers, IdGenerator idGenerator) {

    if (reader == null) {
      return new BoardReadResult.ParseError("json_root", "Reader must not be null");
    }

    long startTime = System.nanoTime();
    if (observers == null) {
      observers = new BoardObserverAdaptor();
    }
    if (idGenerator == null) {
      idGenerator = new ItemIdGenerator();
    }

    try {
      // 1. Deserialize JSON
      KiCadBoardJson boardJson = GsonProvider.GSON.fromJson(reader, KiCadBoardJson.class);
      if (boardJson == null) {
        return new BoardReadResult.ParseError("json_root", "JSON payload is empty or invalid");
      }

      long parseEndTime = System.nanoTime();
      double parseMs = (parseEndTime - startTime) / 1_000_000.0;
      FRLogger.debug(
          String.format("KiCad JSON Deserialization performance: parsed in %.2f ms", parseMs));

      // 2. Set up units and scaling
      Unit userUnit = Unit.MM;
      if (boardJson.unit == KiCadBoardJson.UnitJson.MIL) {
        userUnit = Unit.MIL;
      } else if (boardJson.unit == KiCadBoardJson.UnitJson.UM) {
        userUnit = Unit.UM;
      }

      // We maintain similar resolution scaling factors as DSN mapping (e.g. 1000 for mm)
      int resolution = (int) Math.max(1.0, boardJson.resolution);
      if (boardJson.resolution == 1.0 && userUnit == Unit.MM) {
        resolution = 10000; // 0.1 micrometer resolution is default for mm if unspecified
      }

      final double scaleFactor = resolution;

      // 3. Layer Structure
      int layerCount = boardJson.layers.isEmpty() ? 2 : boardJson.layers.size();
      Layer[] boardLayers = new Layer[layerCount];
      if (boardJson.layers.isEmpty()) {
        boardLayers[0] = new Layer("F.Cu", true);
        boardLayers[1] = new Layer("B.Cu", true);
      } else {
        for (int i = 0; i < layerCount; i++) {
          KiCadBoardJson.LayerJson layerJson = boardJson.layers.get(i);
          boolean isSignal = !"plane".equalsIgnoreCase(layerJson.type);
          boardLayers[i] = new Layer(layerJson.name, isSignal);
        }
      }
      LayerStructure layerStructure = new LayerStructure(boardLayers);
      app.freerouting.io.specctra.parser.LayerStructure specctraLayerStructure =
          new app.freerouting.io.specctra.parser.LayerStructure(
              layerStructure); // dummy or map layer names if needed

      // 4. Clearance Matrix
      List<KiCadBoardJson.NetClassJson> additionalNetClasses =
          nonDefaultNetClasses(boardJson.netClasses);

      boolean hasEdgeClearance = boardJson.outline != null && boardJson.outline.clearance > 0;
      int edgeClassOffset = hasEdgeClearance ? 1 : 0;

      int clearanceClassCount = Math.max(2, additionalNetClasses.size() + 2 + edgeClassOffset);
      String[] clearanceClassNames = new String[clearanceClassCount];
      clearanceClassNames[0] = "null";
      clearanceClassNames[1] = "default";
      for (int i = 0; i < additionalNetClasses.size(); i++) {
        clearanceClassNames[i + 2] = additionalNetClasses.get(i).name;
      }
      if (hasEdgeClearance) {
        clearanceClassNames[clearanceClassCount - 1] = BOARD_EDGE_CLEARANCE_CLASS_NAME;
      }

      ClearanceMatrix clearanceMatrix =
          new ClearanceMatrix(clearanceClassCount, layerStructure, clearanceClassNames);
      int defaultClearance =
          (int) Math.round(Unit.scale(0.2, Unit.MM, userUnit) * scaleFactor); // fallback 0.2mm
      clearanceMatrix.setDefaultValue(defaultClearance);

      KiCadBoardJson.NetClassJson kiCadDefaultNetClass =
          findKiCadDefaultNetClass(boardJson.netClasses);
      if (kiCadDefaultNetClass != null && kiCadDefaultNetClass.clearance > 0) {
        int defaultClVal = (int) Math.round(kiCadDefaultNetClass.clearance * scaleFactor);
        clearanceMatrix.setValue(1, 1, defaultClVal);
      }

      // Populate clearance matrix from non-default NetClasses and Custom Clearance Rules
      for (int i = 0; i < additionalNetClasses.size(); i++) {
        KiCadBoardJson.NetClassJson nc = additionalNetClasses.get(i);
        int clNo = i + 2;
        int clVal = (int) Math.round(nc.clearance * scaleFactor);
        clearanceMatrix.setValue(clNo, clNo, clVal);
        clearanceMatrix.setValue(1, clNo, clVal); // spacing between default and class
      }

      if (hasEdgeClearance) {
        int boardEdgeClassNo = clearanceMatrix.getNo(BOARD_EDGE_CLEARANCE_CLASS_NAME);
        int edgeClVal = (int) Math.round(boardJson.outline.clearance * scaleFactor);
        for (int c = 1; c < clearanceClassCount; c++) {
          clearanceMatrix.setValue(boardEdgeClassNo, c, edgeClVal);
          clearanceMatrix.setValue(c, boardEdgeClassNo, edgeClVal);
        }
      }

      for (KiCadBoardJson.CustomClearanceRuleJson rule : boardJson.clearanceRules) {
        int idxA = clearanceMatrix.getNo(rule.classA);
        int idxB = clearanceMatrix.getNo(rule.classB);
        if (idxA >= 0 && idxB >= 0) {
          int clearanceVal = (int) Math.round(rule.clearance * scaleFactor);
          clearanceMatrix.setValue(idxA, idxB, clearanceVal);
        }
      }

      // 5. Board Outline / Boundary Shape Creation
      List<PolylineShape> outlineShapes;
      IntBox boundingBox;
      final boolean outlineMissing =
          boardJson.outline == null || boardJson.outline.corners.size() < 3;
      if (outlineMissing) {
        outlineShapes = new ArrayList<>();
        final PointOutline outline = new PointOutline();
        FRLogger.warn(
            "Board Outline/Boundary is missing or empty in the JSON file. A supposed board edge "
                + "around components with 5mm padding will be generated for routing.");
        double minX = Double.MAX_VALUE;
        double maxX = -Double.MAX_VALUE;
        double minY = Double.MAX_VALUE;
        double maxY = -Double.MAX_VALUE;

        // Check components and pads
        if (boardJson.components != null) {
          for (KiCadBoardJson.ComponentJson comp : boardJson.components) {
            if (comp.position != null) {
              minX = Math.min(minX, comp.position.x);
              maxX = Math.max(maxX, comp.position.x);
              minY = Math.min(minY, comp.position.y);
              maxY = Math.max(maxY, comp.position.y);
            }
            if (comp.pads != null) {
              for (KiCadBoardJson.PadJson pad : comp.pads) {
                if (pad.position != null) {
                  minX = Math.min(minX, pad.position.x);
                  maxX = Math.max(maxX, pad.position.x);
                  minY = Math.min(minY, pad.position.y);
                  maxY = Math.max(maxY, pad.position.y);
                }
              }
            }
          }
        }

        // Check vias
        if (boardJson.vias != null) {
          for (KiCadBoardJson.ViaJson via : boardJson.vias) {
            if (via.position != null) {
              minX = Math.min(minX, via.position.x);
              maxX = Math.max(maxX, via.position.x);
              minY = Math.min(minY, via.position.y);
              maxY = Math.max(maxY, via.position.y);
            }
          }
        }

        // Check traces
        if (boardJson.traces != null) {
          for (KiCadBoardJson.TraceJson trace : boardJson.traces) {
            if (trace.points != null) {
              for (KiCadBoardJson.Point2D pt : trace.points) {
                minX = Math.min(minX, pt.x);
                maxX = Math.max(maxX, pt.x);
                minY = Math.min(minY, pt.y);
                maxY = Math.max(maxY, pt.y);
              }
            }
          }
        }

        // Check conduction areas
        if (boardJson.conductionAreas != null) {
          for (KiCadBoardJson.ConductionAreaJson zone : boardJson.conductionAreas) {
            if (zone.polygon != null) {
              for (KiCadBoardJson.Point2D pt : zone.polygon) {
                minX = Math.min(minX, pt.x);
                maxX = Math.max(maxX, pt.x);
                minY = Math.min(minY, pt.y);
                maxY = Math.max(maxY, pt.y);
              }
            }
          }
        }

        double padding = Unit.scale(5.0, Unit.MM, userUnit);

        if (minX == Double.MAX_VALUE) {
          // No items found on the board at all, fallback to a default 1000x1000 region in internal
          // units
          minX = 0;
          maxX = 1000 / scaleFactor;
          minY = -1000 / scaleFactor;
          maxY = 0;
        }

        // Apply padding
        minX -= padding;
        maxX += padding;
        minY -= padding;
        maxY += padding;

        Point[] points = new Point[4];
        points[0] =
            new IntPoint(
                (int) Math.round(minX * scaleFactor), (int) Math.round(-minY * scaleFactor));
        points[1] =
            new IntPoint(
                (int) Math.round(minX * scaleFactor), (int) Math.round(-maxY * scaleFactor));
        points[2] =
            new IntPoint(
                (int) Math.round(maxX * scaleFactor), (int) Math.round(-maxY * scaleFactor));
        points[3] =
            new IntPoint(
                (int) Math.round(maxX * scaleFactor), (int) Math.round(-minY * scaleFactor));

        for (Point point : points) {
          outline.addPoint(point.toFloat());
        }
        outlineShapes.add(new PolygonShape(points));
        boundingBox = outline.boundingBox().offset(1000);
      } else {
        outlineShapes = new ArrayList<>();
        PointOutline outline = new PointOutline();
        List<KiCadBoardJson.Point2D> corners = new ArrayList<>(boardJson.outline.corners);
        if (corners.size() > 2) {
          // Sort corners by polar angle around centroid to ensure simple polygon construction
          double sumX = 0;
          double sumY = 0;
          for (KiCadBoardJson.Point2D pt : corners) {
            sumX += pt.x;
            sumY += pt.y;
          }
          final double cx = sumX / corners.size();
          final double cy = sumY / corners.size();
          corners.sort(
              (p1, p2) ->
                  Double.compare(
                      Math.atan2(p1.y - cy, p1.x - cx), Math.atan2(p2.y - cy, p2.x - cx)));
        }
        Point[] points = new Point[corners.size()];
        for (int i = 0; i < corners.size(); i++) {
          KiCadBoardJson.Point2D pt = corners.get(i);
          points[i] =
              new IntPoint(
                  (int) Math.round(pt.x * scaleFactor), (int) Math.round(-pt.y * scaleFactor));
          outline.addPoint(points[i].toFloat());
        }
        outlineShapes.add(new PolygonShape(points));
        boundingBox = outline.boundingBox().offset(1000);
      }

      final int outlineClearanceNo =
          hasEdgeClearance ? clearanceMatrix.getNo(BOARD_EDGE_CLEARANCE_CLASS_NAME) : 1;

      // 6. Communication object setup
      final CoordinateTransform coordinateTransform = new CoordinateTransform(scaleFactor, 0, 0);
      String hostCad =
          boardJson.hostCad != null && !boardJson.hostCad.isBlank() ? boardJson.hostCad : "KiCad";
      String hostVersion =
          boardJson.hostVersion != null && !boardJson.hostVersion.isBlank()
              ? boardJson.hostVersion
              : "v10.0";
      Communication.SpecctraParserInfo parserInfo =
          new Communication.SpecctraParserInfo("\"", hostCad, hostVersion, null, null, false);
      Communication communication =
          new Communication(
              userUnit, resolution, parserInfo, coordinateTransform, idGenerator, observers);

      // 7. Construct RoutingBoard
      final BoardRules boardRules = new BoardRules(layerStructure, clearanceMatrix);
      RoutingBoard board =
          new RoutingBoard(
              boundingBox,
              layerStructure,
              outlineShapes.toArray(new PolylineShape[0]),
              outlineClearanceNo,
              boardRules,
              communication);

      board.library.padstacks = new Padstacks(layerStructure);
      board.library.packages = new Packages(board.library.padstacks);

      // 8. Populate Net Classes & Netlist in Rules (now that board is fully linked)
      boardRules.createDefaultNetClass();
      NetClass defaultNetClass = boardRules.getDefaultNetClass();
      Map<String, Integer> netClassIndexMap = new HashMap<>();
      if (kiCadDefaultNetClass != null) {
        applyKiCadNetClassParameters(
            defaultNetClass, kiCadDefaultNetClass, layerCount, scaleFactor, 1);
      }

      for (int i = 0; i < additionalNetClasses.size(); i++) {
        KiCadBoardJson.NetClassJson nc = additionalNetClasses.get(i);
        int clNo = i + 2;
        NetClass boardNetClass =
            boardRules.netClasses.append(nc.name, layerStructure, clearanceMatrix, false);
        applyKiCadNetClassParameters(boardNetClass, nc, layerCount, scaleFactor, clNo);
        netClassIndexMap.put(nc.name, clNo);
      }

      // Create via rules and register via padstacks so that the router is allowed to use vias
      double defaultViaDiameter = 0.8;
      double defaultViaDrill = 0.4;
      if (userUnit == Unit.MIL) {
        defaultViaDiameter = 30.0;
        defaultViaDrill = 15.0;
      } else if (userUnit == Unit.UM) {
        defaultViaDiameter = 800.0;
        defaultViaDrill = 400.0;
      }

      double defViaDia = defaultViaDiameter;
      double defViaDrill = defaultViaDrill;
      if (kiCadDefaultNetClass != null) {
        if (kiCadDefaultNetClass.viaDiameter > 0) {
          defViaDia = kiCadDefaultNetClass.viaDiameter;
        }
        if (kiCadDefaultNetClass.viaDrill > 0) {
          defViaDrill = kiCadDefaultNetClass.viaDrill;
        }
      }

      ConvexShape[] defViaShapeArr = new ConvexShape[layerCount];
      double defRadius = defViaDia * scaleFactor / 2.0;
      ConvexShape defViaShape = new Circle(IntPoint.ZERO, (int) Math.round(defRadius));
      for (int li = 0; li < layerCount; li++) {
        defViaShapeArr[li] = defViaShape;
      }
      Padstack defaultViaPadstack =
          board.library.padstacks.add("defaultVia", defViaShapeArr, true, false);
      board.library.addViaPadstack(defaultViaPadstack);

      int defaultViaClClass =
          defaultNetClass.defaultItemClearanceClasses.get(
              DefaultItemClearanceClasses.ItemClass.VIA);
      ViaInfo defaultViaInfo =
          new ViaInfo("defaultVia", defaultViaPadstack, defaultViaClClass, true, boardRules);
      boardRules.viaInfos.add(defaultViaInfo);

      ViaRule defaultViaRule = new ViaRule("default");
      defaultViaRule.appendVia(defaultViaInfo);
      boardRules.viaRules.add(defaultViaRule);
      defaultNetClass.setViaRule(defaultViaRule);

      for (int i = 0; i < additionalNetClasses.size(); i++) {
        KiCadBoardJson.NetClassJson nc = additionalNetClasses.get(i);
        int clNo = i + 2;
        NetClass boardNetClass = boardRules.netClasses.get(clNo - 1);

        double viaDia = nc.viaDiameter > 0 ? nc.viaDiameter : defViaDia;
        double viaDrill = nc.viaDrill > 0 ? nc.viaDrill : defViaDrill;

        ConvexShape[] viaShapeArr = new ConvexShape[layerCount];
        double radius = viaDia * scaleFactor / 2.0;
        ConvexShape viaShape = new Circle(IntPoint.ZERO, (int) Math.round(radius));
        for (int li = 0; li < layerCount; li++) {
          viaShapeArr[li] = viaShape;
        }

        String viaName = "via_" + nc.name;
        Padstack viaPadstack = board.library.padstacks.add(viaName, viaShapeArr, true, false);
        board.library.addViaPadstack(viaPadstack);

        int viaClClass =
            boardNetClass.defaultItemClearanceClasses.get(
                DefaultItemClearanceClasses.ItemClass.VIA);
        ViaInfo viaInfo = new ViaInfo(viaName, viaPadstack, viaClClass, true, boardRules);
        boardRules.viaInfos.add(viaInfo);

        ViaRule viaRule = new ViaRule(nc.name);
        viaRule.appendVia(viaInfo);
        boardRules.viaRules.add(viaRule);
        boardNetClass.setViaRule(viaRule);
      }

      // Add actual nets
      int maxNetNo = boardJson.nets.size();
      for (KiCadBoardJson.NetJson nj : boardJson.nets) {
        Net boardNet = boardRules.nets.add(nj.name, 1, nj.containsPlane);
        int clNo = resolveNetClassIndex(netClassIndexMap, nj.className);
        boardNet.setClass(
            boardRules.netClasses.get(clNo - 1)); // NetClass array indices are 0-based
      }

      // Automatically register any referenced nets that were not explicitly defined in the nets
      // list
      java.util.Set<String> referencedNets = new java.util.HashSet<>();
      if (boardJson.components != null) {
        for (KiCadBoardJson.ComponentJson comp : boardJson.components) {
          if (comp.pads != null) {
            for (KiCadBoardJson.PadJson pad : comp.pads) {
              if (pad.netName != null && !pad.netName.isEmpty()) {
                referencedNets.add(pad.netName);
              }
            }
          }
        }
      }
      if (boardJson.conductionAreas != null) {
        for (KiCadBoardJson.ConductionAreaJson zone : boardJson.conductionAreas) {
          if (zone.netName != null && !zone.netName.isEmpty()) {
            referencedNets.add(zone.netName);
          }
        }
      }
      if (boardJson.traces != null) {
        for (KiCadBoardJson.TraceJson tr : boardJson.traces) {
          if (tr.netName != null && !tr.netName.isEmpty()) {
            referencedNets.add(tr.netName);
          }
        }
      }
      if (boardJson.vias != null) {
        for (KiCadBoardJson.ViaJson vj : boardJson.vias) {
          if (vj.netName != null && !vj.netName.isEmpty()) {
            referencedNets.add(vj.netName);
          }
        }
      }

      for (String netName : referencedNets) {
        if (boardRules.nets.get(netName, 1) == null) {
          Net boardNet = boardRules.nets.add(netName, 1, false);
          // Fallback to default class (default net class is at index 0)
          boardNet.setClass(boardRules.netClasses.get(0));
        }
      }

      // 9. Load Components & Library templates
      Padstacks padstacks = board.library.padstacks;
      Packages packages = board.library.packages;

      // Populate footprint templates
      for (KiCadBoardJson.ComponentJson comp : boardJson.components) {
        // Create padstacks and pins for the component package
        List<Package.Pin> packagePins = new ArrayList<>();
        for (KiCadBoardJson.PadJson pad : comp.pads) {
          // Define a default pad shape
          final ConvexShape[] shapes = new ConvexShape[layerCount];
          double dx = pad.size.x * scaleFactor / 2.0;
          double dy = pad.size.y * scaleFactor / 2.0;
          ConvexShape padShape;
          if ("circle".equalsIgnoreCase(pad.shape)) {
            double radius = Math.min(pad.size.x, pad.size.y) * scaleFactor / 2.0;
            padShape = new Circle(IntPoint.ZERO, (int) Math.round(radius));
          } else if ("oval".equalsIgnoreCase(pad.shape)) {
            int lx = (int) Math.round(-dx);
            int rx = (int) Math.round(dx);
            int ly = (int) Math.round(-dy);
            int uy = (int) Math.round(dy);
            int r = (int) Math.round(Math.min(dx, dy));
            int cut = (int) Math.round((2.0 - Math.sqrt(2.0)) * r);
            IntOctagon oct =
                new IntOctagon(
                    lx, ly, rx, uy, lx - uy + cut, rx - ly - cut, lx + ly + cut, rx + uy - cut);
            padShape = oct.toSimplex();
          } else {
            padShape =
                new IntBox(
                        (int) Math.round(-dx),
                        (int) Math.round(-dy),
                        (int) Math.round(dx),
                        (int) Math.round(dy))
                    .toSimplex();
          }

          // Standardize pad's layer mappings
          int startLayer = 0;
          int endLayer = layerCount - 1;
          boolean hasMatchedCopperLayer = false;
          if (pad.layers != null && !pad.layers.isEmpty()) {
            int lowestIdx = layerCount - 1;
            int highestIdx = 0;
            for (String layerName : pad.layers) {
              if ("*.Cu".equalsIgnoreCase(layerName) || "all".equalsIgnoreCase(layerName)) {
                lowestIdx = 0;
                highestIdx = layerCount - 1;
                hasMatchedCopperLayer = true;
                break;
              }
              for (int li = 0; li < layerCount; li++) {
                if (boardLayers[li].name.equalsIgnoreCase(layerName)) {
                  lowestIdx = Math.min(lowestIdx, li);
                  highestIdx = Math.max(highestIdx, li);
                  hasMatchedCopperLayer = true;
                }
              }
            }
            if (hasMatchedCopperLayer) {
              startLayer = lowestIdx;
              endLayer = highestIdx;
            }
          }

          boolean isDrillable = pad.drill > 0.0;
          // If no copper layers matched explicitly:
          // - If it has a drill hole (e.g. NPTH mounting hole), it spans all layers.
          // - Otherwise, default to package-relative layer 0. When placed on the back side,
          //   DrillItem automatically mirrors layer 0 to the bottom layer.
          if (!hasMatchedCopperLayer && !isDrillable) {
            startLayer = 0;
            endLayer = 0;
          }

          for (int li = startLayer; li <= endLayer; li++) {
            shapes[li] = padShape;
          }

          String padstackName = getDescriptivePadstackName(pad, layerCount, startLayer, endLayer);
          Padstack padstack = padstacks.get(padstackName);
          if (padstack == null) {
            padstack = padstacks.add(padstackName, shapes, isDrillable, false);
          }
          IntVector relativeLoc =
              new IntVector(
                  (int) Math.round(pad.offset.x * scaleFactor),
                  (int) Math.round(-pad.offset.y * scaleFactor));
          packagePins.add(new Package.Pin(pad.name, padstack.id, relativeLoc, 0.0));
        }

        boolean isFront = !"B.Cu".equalsIgnoreCase(comp.layer);
        String basePackageName = comp.footprint;
        if (basePackageName == null || basePackageName.isEmpty()) {
          basePackageName = "Package";
        }
        Package.Pin[] newPinArr = packagePins.toArray(new Package.Pin[0]);
        Package componentPackage = null;
        int suffix = 0;
        while (true) {
          String testName = suffix == 0 ? basePackageName : basePackageName + "::" + suffix;
          try {
            Package existingPkg = packages.get(testName, isFront);
            if (existingPkg == null || !existingPkg.name.equalsIgnoreCase(testName)) {
              componentPackage =
                  packages.add(
                      testName,
                      newPinArr,
                      null,
                      null,
                      null,
                      new Package.Keepout[0],
                      new Package.Keepout[0],
                      new Package.Keepout[0],
                      isFront);
              break;
            } else {
              if (arePackagePinsIdentical(existingPkg, newPinArr)) {
                componentPackage = existingPkg;
                break;
              }
            }
          } catch (Exception e) {
            FRLogger.error("KiCadJsonReader package deduplication error, falling back", e);
            componentPackage =
                packages.add(
                    comp.footprint != null ? comp.footprint : "Package",
                    newPinArr,
                    null,
                    null,
                    null,
                    new Package.Keepout[0],
                    new Package.Keepout[0],
                    new Package.Keepout[0],
                    isFront);
            break;
          }
          suffix++;
        }
        IntPoint position =
            new IntPoint(
                (int) Math.round(comp.position.x * scaleFactor),
                (int) Math.round(-comp.position.y * scaleFactor));

        Component boardComp =
            board.components.add(
                comp.reference,
                position,
                comp.rotation,
                isFront,
                componentPackage,
                componentPackage,
                true,
                comp.value);

        // Insert actual pin items mapped to nets
        for (int padIndex = 0; padIndex < comp.pads.size(); padIndex++) {
          KiCadBoardJson.PadJson pad = comp.pads.get(padIndex);
          Net targetNet = boardRules.nets.get(pad.netName, 1);
          int netNumber = targetNet != null ? targetNet.netNumber : 0;
          int[] netNumbers = netNumber > 0 ? new int[] {netNumber} : new int[0];
          board.insertPin(boardComp.id, padIndex, netNumbers, 1, FixedState.SYSTEM_FIXED);
        }
      }

      // 10. Load conduction areas (copper pours)
      for (KiCadBoardJson.ConductionAreaJson zone : boardJson.conductionAreas) {
        Net targetNet = boardRules.nets.get(zone.netName, 1);
        int netNumber = targetNet != null ? targetNet.netNumber : 0;
        int[] netNumbers = netNumber > 0 ? new int[] {netNumber} : new int[0];

        // Build Area path polygon
        Point[] zonePoints = new Point[zone.polygon.size()];
        for (int i = 0; i < zone.polygon.size(); i++) {
          KiCadBoardJson.Point2D pt = zone.polygon.get(i);
          zonePoints[i] =
              new IntPoint(
                  (int) Math.round(pt.x * scaleFactor), (int) Math.round(-pt.y * scaleFactor));
        }
        Area zoneArea = new PolygonShape(zonePoints);
        board.insertConductionArea(
            zoneArea, zone.layerIndex, netNumbers, 1, zone.isObstacle, FixedState.USER_FIXED);
      }

      // 11. Load traces and vias (existing wiring)
      for (KiCadBoardJson.TraceJson tr : boardJson.traces) {
        Net targetNet = boardRules.nets.get(tr.netName, 1);
        int netNumber = targetNet != null ? targetNet.netNumber : 0;
        int[] netNumbers = netNumber > 0 ? new int[] {netNumber} : new int[0];
        int traceHalfWidth = (int) Math.round(tr.width * scaleFactor / 2.0);

        Point[] points = new Point[tr.points.size()];
        for (int i = 0; i < tr.points.size(); i++) {
          KiCadBoardJson.Point2D pt = tr.points.get(i);
          points[i] =
              new IntPoint(
                  (int) Math.round(pt.x * scaleFactor), (int) Math.round(-pt.y * scaleFactor));
        }
        board.insertTrace(
            points, tr.layerIndex, traceHalfWidth, netNumbers, 1, FixedState.USER_FIXED);
      }

      for (KiCadBoardJson.ViaJson vj : boardJson.vias) {
        Net targetNet = boardRules.nets.get(vj.netName, 1);
        int netNumber = targetNet != null ? targetNet.netNumber : 0;
        int[] netNumbers = netNumber > 0 ? new int[] {netNumber} : new int[0];

        IntPoint center =
            new IntPoint(
                (int) Math.round(vj.position.x * scaleFactor),
                (int) Math.round(-vj.position.y * scaleFactor));

        // Dynamically create via padstack
        ConvexShape[] shapes = new ConvexShape[layerCount];
        double radius = vj.diameter * scaleFactor / 2.0;
        ConvexShape viaShape = new Circle(IntPoint.ZERO, (int) Math.round(radius));

        for (int li = vj.startLayerIndex; li <= vj.endLayerIndex; li++) {
          shapes[li] = viaShape;
        }
        String viaPadstackName =
            String.format(
                "Via[%d-%d]_%.0f:%.0f_um",
                vj.startLayerIndex, vj.endLayerIndex, vj.diameter * 1000.0, vj.drill * 1000.0);
        Padstack viaPadstack = padstacks.get(viaPadstackName);
        if (viaPadstack == null) {
          viaPadstack = padstacks.add(viaPadstackName, shapes, true, false);
        }
        board.insertVia(viaPadstack, center, netNumbers, 1, FixedState.USER_FIXED, true);
      }

      long endTime = System.nanoTime();
      double durationMs = (endTime - startTime) / 1_000_000.0;
      FRLogger.debug(
          String.format(
              "KiCad JSON Loader performance: built RoutingBoard in %.2f ms (parsing + "
                  + "structure mapping)",
              durationMs));

      // Build metadata for the board
      BoardMetadata metadata =
          new BoardMetadata(
              "KiCad",
              "v10.0",
              layerCount,
              userUnit,
              resolution,
              AngleRestriction.FORTYFIVE_DEGREE,
              null);

      List<String> warnings = new ArrayList<>();
      if (outlineMissing) {
        warnings.add(
            "Board Outline/Boundary is missing or empty in the JSON file. A supposed board edge "
                + "around components with 5mm padding was generated.");
      }
      return new BoardReadResult.Success(board, metadata, warnings);

    } catch (Throwable e) {
      FRLogger.warn("Failed to parse and read KiCad JSON board: " + e.getMessage());
      return new BoardReadResult.ParseError(
          "json_payload", "Exception occurred: " + e.getMessage());
    }
  }

  /**
   * Imports traces, vias, and conduction areas from a KiCad session JSON file onto an existing
   * board.
   */
  public static void importSession(Reader reader, RoutingBoard board) throws Exception {
    KiCadBoardJson boardJson = GsonProvider.GSON.fromJson(reader, KiCadBoardJson.class);
    if (boardJson == null) {
      throw new IllegalArgumentException("JSON session file payload is empty or invalid");
    }

    Unit userUnit = Unit.MM;
    if (boardJson.unit == KiCadBoardJson.UnitJson.MIL) {
      userUnit = Unit.MIL;
    } else if (boardJson.unit == KiCadBoardJson.UnitJson.UM) {
      userUnit = Unit.UM;
    }

    int resolution = (int) Math.max(1.0, boardJson.resolution);
    if (boardJson.resolution == 1.0 && userUnit == Unit.MM) {
      resolution = 10000;
    }
    double scaleFactor = resolution;

    // 1. Conduction Areas
    if (boardJson.conductionAreas != null) {
      for (KiCadBoardJson.ConductionAreaJson zone : boardJson.conductionAreas) {
        Net targetNet = board.rules.nets.get(zone.netName, 1);
        int netNumber = targetNet != null ? targetNet.netNumber : 0;
        int[] netNumbers = netNumber > 0 ? new int[] {netNumber} : new int[0];

        Point[] zonePoints = new Point[zone.polygon.size()];
        for (int i = 0; i < zone.polygon.size(); i++) {
          KiCadBoardJson.Point2D pt = zone.polygon.get(i);
          zonePoints[i] =
              new IntPoint(
                  (int) Math.round(pt.x * scaleFactor), (int) Math.round(-pt.y * scaleFactor));
        }
        Area zoneArea = new PolygonShape(zonePoints);
        board.insertConductionArea(
            zoneArea, zone.layerIndex, netNumbers, 1, zone.isObstacle, FixedState.USER_FIXED);
      }
    }

    // 2. Traces
    if (boardJson.traces != null) {
      for (KiCadBoardJson.TraceJson tr : boardJson.traces) {
        Net targetNet = board.rules.nets.get(tr.netName, 1);
        int netNumber = targetNet != null ? targetNet.netNumber : 0;
        int[] netNumbers = netNumber > 0 ? new int[] {netNumber} : new int[0];
        int traceHalfWidth = (int) Math.round(tr.width * scaleFactor / 2.0);

        Point[] points = new Point[tr.points.size()];
        for (int i = 0; i < tr.points.size(); i++) {
          KiCadBoardJson.Point2D pt = tr.points.get(i);
          points[i] =
              new IntPoint(
                  (int) Math.round(pt.x * scaleFactor), (int) Math.round(-pt.y * scaleFactor));
        }
        board.insertTrace(
            points, tr.layerIndex, traceHalfWidth, netNumbers, 1, FixedState.USER_FIXED);
      }
    }

    // 3. Vias
    if (boardJson.vias != null) {
      int layerCount = board.getLayerCount();
      for (KiCadBoardJson.ViaJson vj : boardJson.vias) {
        Net targetNet = board.rules.nets.get(vj.netName, 1);
        int netNumber = targetNet != null ? targetNet.netNumber : 0;
        int[] netNumbers = netNumber > 0 ? new int[] {netNumber} : new int[0];

        IntPoint center =
            new IntPoint(
                (int) Math.round(vj.position.x * scaleFactor),
                (int) Math.round(-vj.position.y * scaleFactor));

        ConvexShape[] shapes = new ConvexShape[layerCount];
        double radius = vj.diameter * scaleFactor / 2.0;
        ConvexShape viaShape = new Circle(IntPoint.ZERO, (int) Math.round(radius));

        for (int li = vj.startLayerIndex; li <= vj.endLayerIndex; li++) {
          if (li >= 0 && li < layerCount) {
            shapes[li] = viaShape;
          }
        }
        String viaPadstackName =
            String.format(
                "Via[%d-%d]_%.0f:%.0f_um",
                vj.startLayerIndex, vj.endLayerIndex, vj.diameter * 1000.0, vj.drill * 1000.0);
        Padstack viaPadstack = board.library.padstacks.get(viaPadstackName);
        if (viaPadstack == null) {
          viaPadstack = board.library.padstacks.add(viaPadstackName, shapes, true, false);
        }
        board.insertVia(viaPadstack, center, netNumbers, 1, FixedState.USER_FIXED, true);
      }
    }
  }

  private static String getDescriptivePadstackName(
      KiCadBoardJson.PadJson pad, int layerCount, int startLayer, int endLayer) {
    String shapeStr = "Round";
    if (pad.shape != null) {
      if ("circle".equalsIgnoreCase(pad.shape) || "round".equalsIgnoreCase(pad.shape)) {
        shapeStr = "Round";
      } else if ("rect".equalsIgnoreCase(pad.shape) || "rectangle".equalsIgnoreCase(pad.shape)) {
        shapeStr = "Rect";
      } else if ("oval".equalsIgnoreCase(pad.shape)) {
        shapeStr = "Oval";
      } else {
        shapeStr = pad.shape.substring(0, 1).toUpperCase() + pad.shape.substring(1).toLowerCase();
      }
    }

    String layerType;
    if (startLayer == 0 && endLayer == layerCount - 1) {
      layerType = "A";
    } else if (startLayer == 0 && endLayer == 0) {
      layerType = "T";
    } else if (startLayer == layerCount - 1 && endLayer == layerCount - 1) {
      layerType = "B";
    } else if (startLayer == endLayer) {
      layerType = "L" + (startLayer + 1);
    } else {
      layerType = String.format(Locale.ROOT, "L%d-L%d", startLayer + 1, endLayer + 1);
    }

    String drillSuffix =
        pad.drill > 0.0 ? String.format(Locale.ROOT, ":%.0f", pad.drill * 1000.0) : "";
    if ("Round".equals(shapeStr)) {
      return String.format(
          Locale.ROOT,
          "%s[%s]Pad_%.0f%s_um",
          shapeStr,
          layerType,
          pad.size.x * 1000.0,
          drillSuffix);
    } else {
      return String.format(
          Locale.ROOT,
          "%s[%s]Pad_%.0fx%.0f%s_um",
          shapeStr,
          layerType,
          pad.size.x * 1000.0,
          pad.size.y * 1000.0,
          drillSuffix);
    }
  }

  private static boolean arePackagePinsIdentical(Package pkg1, Package.Pin[] p2) {
    if (pkg1 == null || p2 == null) {
      return (pkg1 == null) == (p2 == null);
    }
    if (pkg1.pinCount() != p2.length) {
      return false;
    }
    for (int i = 0; i < p2.length; i++) {
      Package.Pin pin1 = pkg1.getPin(i);
      Package.Pin pin2 = p2[i];
      if (pin1 == null || pin2 == null) {
        if (pin1 != pin2) {
          return false;
        }
        continue;
      }
      if (!pin1.name.equals(pin2.name)) {
        return false;
      }
      if (pin1.padstackId != pin2.padstackId) {
        return false;
      }
      app.freerouting.geometry.planar.FloatPoint loc1 = pin1.relativeLocation.toFloat();
      app.freerouting.geometry.planar.FloatPoint loc2 = pin2.relativeLocation.toFloat();
      if (Math.abs(loc1.x - loc2.x) > 0.001 || Math.abs(loc1.y - loc2.y) > 0.001) {
        return false;
      }
      if (Math.abs(pin1.rotationInDegree - pin2.rotationInDegree) > 0.001) {
        return false;
      }
    }
    return true;
  }

  private static KiCadBoardJson.NetClassJson findKiCadDefaultNetClass(
      List<KiCadBoardJson.NetClassJson> netClasses) {
    for (KiCadBoardJson.NetClassJson netClass : netClasses) {
      if (KiCadNetClassNames.isKiCadDefaultNetClassName(netClass.name)) {
        return netClass;
      }
    }
    return null;
  }

  private static List<KiCadBoardJson.NetClassJson> nonDefaultNetClasses(
      List<KiCadBoardJson.NetClassJson> netClasses) {
    List<KiCadBoardJson.NetClassJson> result = new ArrayList<>();
    for (KiCadBoardJson.NetClassJson netClass : netClasses) {
      if (!KiCadNetClassNames.isKiCadDefaultNetClassName(netClass.name)) {
        result.add(netClass);
      }
    }
    return result;
  }

  private static void applyKiCadNetClassParameters(
      NetClass target,
      KiCadBoardJson.NetClassJson source,
      int layerCount,
      double scaleFactor,
      int clearanceClassIndex) {
    if (source.traceWidth > 0) {
      int traceHalfWidth = (int) Math.round(source.traceWidth * scaleFactor / 2.0);
      for (int layer = 0; layer < layerCount; layer++) {
        target.setTraceHalfWidth(layer, traceHalfWidth);
      }
    }
    if (source.clearance > 0) {
      target.setTraceClearanceClass(clearanceClassIndex);
    }
  }

  private static int resolveNetClassIndex(Map<String, Integer> netClassIndexMap, String className) {
    if (KiCadNetClassNames.isKiCadDefaultNetClassName(className)) {
      return 1;
    }
    Integer classIndex = netClassIndexMap.get(className);
    if (classIndex != null) {
      return classIndex;
    }
    for (Map.Entry<String, Integer> entry : netClassIndexMap.entrySet()) {
      if (entry.getKey().equalsIgnoreCase(className)) {
        return entry.getValue();
      }
    }
    return 1;
  }

  /** Helper class to trace bounding outer box. */
  private static class PointOutline {
    private final List<FloatPoint> points = new ArrayList<>();

    /** Adds a point to the outline. */
    public void addPoint(FloatPoint pt) {
      points.add(pt);
    }

    /** Returns the integer bounding box of the outline points. */
    public IntBox boundingBox() {
      if (points.isEmpty()) {
        return IntBox.EMPTY;
      }
      double minX = Double.MAX_VALUE;
      double minY = Double.MAX_VALUE;
      double maxX = -Double.MAX_VALUE;
      double maxY = -Double.MAX_VALUE;
      for (FloatPoint pt : points) {
        minX = Math.min(minX, pt.x);
        minY = Math.min(minY, pt.y);
        maxX = Math.max(maxX, pt.x);
        maxY = Math.max(maxY, pt.y);
      }
      return new IntBox(
          (int) Math.round(minX),
          (int) Math.round(minY),
          (int) Math.round(maxX),
          (int) Math.round(maxY));
    }
  }
}
