package app.freerouting.core;

import app.freerouting.board.facade.BasicBoard;
import app.freerouting.core.events.BoardFileDetailsUpdatedEvent;
import app.freerouting.core.events.BoardFileDetailsUpdatedEventListener;
import app.freerouting.core.scoring.BoardStatistics;
import app.freerouting.io.FileFormat;
import app.freerouting.logger.FRLogger;
import app.freerouting.util.gson.GsonProvider;
import com.google.gson.annotations.SerializedName;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.CRC32;

/** Stores file data, metadata, and derived board statistics. */
public class BoardFileDetails implements Serializable {

  protected final transient List<BoardFileDetailsUpdatedEventListener> updatedEventListeners =
      new ArrayList<>();

  // The size of the file in bytes
  @SerializedName("size")
  public long size;

  // The CRC32 checksum of the data
  @SerializedName("crc32")
  public long crc32;

  // The format of the file
  @SerializedName("format")
  public FileFormat format = FileFormat.UNKNOWN;

  @SerializedName("statistics")
  public BoardStatistics statistics = new BoardStatistics();

  // The filename only without the path
  @SerializedName("filename")
  protected String filename = "";

  // The absolute path to the directory of the file
  @SerializedName("path")
  protected String directoryPath = "";

  protected transient byte[] dataBytes = new byte[0];

  /** Creates empty file details. */
  public BoardFileDetails() {}

  /** Creates a new BoardDetails object from a file. */
  public BoardFileDetails(File file) {
    this.setFilename(file.getAbsolutePath());

    try (FileInputStream fis = new FileInputStream(file)) {
      this.setData(fis.readAllBytes());
    } catch (IOException _) {
      // Ignore the exception and continue with the default values
    }
  }

  /** Creates a new BoardDetails object from a RoutingBoard object. */
  public BoardFileDetails(BasicBoard board) {
    this.statistics = new BoardStatistics(board);
  }

  /** Calculates the CRC32 checksum of the supplied stream. */
  public static CRC32 calculateCrc32(InputStream inputStream) {
    CRC32 crc = new CRC32();
    try {
      byte[] buffer = new byte[8192];
      int bytesRead;
      while ((bytesRead = inputStream.read(buffer)) != -1) {
        crc.update(buffer, 0, bytesRead);
      }
    } catch (IOException e) {
      FRLogger.error(e.getLocalizedMessage(), e);
    }
    return crc;
  }

  /** Saves this object to a UTF-8 JSON file. */
  public void saveAs(String filename) throws IOException {
    try (Writer writer = Files.newBufferedWriter(Path.of(filename))) {
      writer.write(this.toString());
    }
  }

  public String getAbsolutePath() {
    return Path.of(this.directoryPath, this.filename).toString();
  }

  public ByteArrayInputStream getData() {
    return new ByteArrayInputStream(this.dataBytes);
  }

  /** Replaces the file data and updates its metadata and statistics. */
  public void setData(byte[] data) {
    this.dataBytes = data;
    this.size = data.length;
    CRC32 crc = new CRC32();
    crc.update(data);
    this.crc32 = crc.getValue();

    // read the file contents to determine the file format
    FileFormat detectedFormat = RoutingJob.getFileFormat(this.dataBytes);
    if (detectedFormat != FileFormat.UNKNOWN) {
      this.format = detectedFormat;
    } else if (this.format == FileFormat.UNKNOWN && !this.filename.isEmpty()) {
      this.format = RoutingJob.getFileFormat(Path.of(this.filename));
    }

    // set the statistical data based on the file content
    this.statistics = new BoardStatistics(this.dataBytes, this.format);

    fireUpdatedEvent();
  }

  /** Returns a JSON representation of this object. */
  public String toString() {
    return GsonProvider.GSON.toJson(this);
  }

  /** Returns the file represented by these details, or {@code null} if no filename is set. */
  public File getFile() {
    if (!this.filename.isEmpty()) {
      return new File(Path.of(this.directoryPath, this.filename).toString());
    }
    return null;
  }

  /** Returns the directory containing the file. */
  public String getDirectoryPath() {
    return this.directoryPath;
  }

  /** Returns the filename without its directory. */
  public String getFilename() {
    return this.filename;
  }

  /**
   * Sets both the filename and the path.*
   *
   * @param filename The filename to set, optionally with its path.
   */
  public void setFilename(String filename) {
    if (filename == null) {
      this.directoryPath = "";
      this.filename = "";
      return;
    }

    String normalized = File.separatorChar == '\\' ? filename : filename.replace('\\', '/');
    var path = Path.of(normalized).toAbsolutePath();

    if (filename.contains("/") || filename.contains("\\")) {
      // separate the filename into its absolute path and its filename only
      Path parent = path.getParent();
      this.directoryPath = parent != null ? parent.toString() : "";
      // replace the redundant "\.\" with a simple "\"
      this.directoryPath = this.directoryPath.replace("\\.\\", "\\");
      // remove the "/", "\" from the end of the directory path
      this.directoryPath = this.directoryPath.replaceAll("[/\\\\]+$", "");
      // remove the "\." from the end of the directory path
      this.directoryPath = this.directoryPath.replaceAll("\\\\.$", "");
    } else {
      this.directoryPath = "";
    }

    // set the filename only
    Path fileName = path.getFileName();
    this.filename = fileName != null ? fileName.toString() : "";

    if (this.format == FileFormat.UNKNOWN) {
      // try to read the file contents to determine the file format
      this.format = RoutingJob.getFileFormat(Path.of(this.filename));
    }

    // add the default file extension if it is missing
    if ((this.format != FileFormat.UNKNOWN) && (!this.filename.contains("."))) {
      String extension =
          switch (this.format) {
            case SES -> "ses";
            case DSN -> "dsn";
            case FRB -> "frb";
            case RULES -> "rules";
            case SCR -> "scr";
            default -> "";
          };

      if (!extension.isEmpty()) {
        this.filename = this.filename + "." + extension;
      }
    }

    fireUpdatedEvent();
  }

  /** Returns the filename without its final extension. */
  public String getFilenameWithoutExtension() {
    if (this.filename.contains(".")) {
      return this.filename.substring(0, this.filename.lastIndexOf('.'));
    }
    return this.filename;
  }

  /** Registers a listener for changes to these details. */
  public void addUpdatedEventListener(BoardFileDetailsUpdatedEventListener listener) {
    updatedEventListeners.add(listener);
  }

  /** Notifies all registered listeners of an update. */
  public void fireUpdatedEvent() {
    BoardFileDetailsUpdatedEvent event = new BoardFileDetailsUpdatedEvent(this, this);
    for (BoardFileDetailsUpdatedEventListener listener : updatedEventListeners) {
      listener.onBoardFileDetailsUpdated(event);
    }
  }
}
