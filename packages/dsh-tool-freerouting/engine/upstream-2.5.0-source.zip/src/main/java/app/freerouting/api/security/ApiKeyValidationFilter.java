package app.freerouting.api.security;

import app.freerouting.logger.FRLogger;
import jakarta.annotation.Priority;
import jakarta.ws.rs.Priorities;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.Provider;
import java.io.IOException;

/**
 * JAX-RS request filter that validates API keys for protected endpoints.
 *
 * <p>This filter intercepts all incoming requests and validates the API key provided in the {@code
 * Authorization: Bearer} header. Certain endpoints are excluded from validation and remain publicly
 * accessible.
 *
 * <h2>Excluded Endpoints (Public Access)</h2>
 *
 * <p>The following endpoints do NOT require API key validation:
 *
 * <ul>
 *   <li><b>/v1/system/*</b> - System monitoring and health check endpoints
 *   <li><b>/v1/analytics/*</b> - Analytics tracking endpoints
 *   <li><b>/dev/*</b> - Development and testing endpoints
 *   <li><b>/openapi/*</b> - OpenAPI specification endpoints
 *   <li><b>/swagger-ui</b> - Swagger UI documentation
 * </ul>
 *
 * <h2>Protected Endpoints</h2>
 *
 * <p>All other endpoints require a valid API key in the {@code Authorization: Bearer <API_KEY>}
 * header.
 *
 * <h2>Error Responses</h2>
 *
 * <ul>
 *   <li><b>401 Unauthorized</b> - Missing or invalid API key
 * </ul>
 *
 * <h2>Configuration</h2>
 *
 * <p>Authentication is configured through the {@code apiServerSettings.authentication} block. The
 * relevant environment variables are:
 *
 * <ul>
 *   <li>{@code FREEROUTING__API_SERVER__AUTHENTICATION__ENABLED} — set to {@code false} for
 *       local/plugin deployments.
 *   <li>{@code FREEROUTING__API_SERVER__AUTHENTICATION__PROVIDERS} — comma-separated provider list
 *       (e.g. {@code "GoogleSheets"}).
 *   <li>{@code FREEROUTING__API_SERVER__AUTHENTICATION__GOOGLE_SHEETS__SHEET_URL}
 *   <li>{@code FREEROUTING__API_SERVER__AUTHENTICATION__GOOGLE_SHEETS__GOOGLE_API_KEY}
 * </ul>
 *
 * <p>If authentication is enabled but no providers are configured, all protected endpoints are
 * denied access (fail-secure).
 *
 * @see ApiKeyProvider
 * @see GoogleSheetsApiKeyProvider
 */
@Provider
@Priority(Priorities.AUTHENTICATION)
public class ApiKeyValidationFilter implements ContainerRequestFilter {

  private static final String AUTHORIZATION_HEADER = "Authorization";
  private static final String BEARER_PREFIX = "Bearer ";

  /** Gets the current API key service (for testing purposes). */
  static ApiKeyValidationService getApiKeyService() {
    return ApiKeyValidationService.getInstance();
  }

  /** Resets the provider initialization state (for testing purposes). */
  static void resetForTesting() {
    ApiKeyValidationService.resetForTesting();
  }

  /**
   * Checks if the request path should be excluded from API key validation.
   *
   * @param path The request path
   * @return {@code true} if the path is excluded, {@code false} otherwise
   */
  private boolean isExcludedPath(String path) {
    if (path == null) {
      return false;
    }

    // Normalize path (remove leading slash for consistent comparison)
    String normalizedPath = path.startsWith("/") ? path.substring(1) : path;

    // Check excluded paths
    return normalizedPath.startsWith("v1/system/")
        || normalizedPath.startsWith("v1/analytics/")
        || normalizedPath.startsWith("dev/")
        || normalizedPath.startsWith("openapi/")
        || "swagger-ui".equals(normalizedPath)
        || normalizedPath.startsWith("swagger-ui/");
  }

  @Override
  public void filter(ContainerRequestContext requestContext) throws IOException {
    String path = requestContext.getUriInfo().getPath();

    // Skip validation for excluded endpoints
    if (isExcludedPath(path)) {
      FRLogger.debug("API key validation skipped for excluded path: " + path);
      return;
    }

    // Service initializes lazily and fetches providers internally.
    ApiKeyValidationService validationService = ApiKeyValidationService.getInstance();

    // If authentication is globally disabled, allow all requests through unconditionally —
    // no header inspection needed. This is the correct behaviour for local/plugin deployments
    // where the operator has explicitly set authentication.enabled=false.
    if (!validationService.isAuthenticationEnabled()) {
      FRLogger.debug("API key validation skipped: authentication is disabled for path " + path);
      return;
    }

    // Get API key from Authorization header
    String authHeader = requestContext.getHeaderString(AUTHORIZATION_HEADER);
    String apiKey = null;

    if (authHeader != null && authHeader.startsWith(BEARER_PREFIX)) {
      apiKey = authHeader.substring(BEARER_PREFIX.length()).trim();
    }

    // Validate API key
    if (apiKey == null || apiKey.isEmpty()) {
      FRLogger.warn(
          "API key validation failed: missing or invalid Authorization header for path " + path);
      abortWithUnauthorized(
          requestContext,
          "Missing API key. Please provide a valid API key in the Authorization header using Bearer scheme (Authorization: Bearer <API_KEY>). You can apply for a free API key at https://www.freerouting.app.");
      return;
    }

    // Validate the API key using the service
    if (!validationService.validateApiKey(apiKey)) {
      FRLogger.warn("API key validation failed: invalid or unauthorized API key for path " + path);
      abortWithUnauthorized(requestContext, "Invalid or unauthorized API key.");
      return;
    }

    // API key is valid, attach the authenticated principal to the SecurityContext
    final String authenticatedPrincipal = apiKey;
    final boolean isSecure =
        requestContext.getSecurityContext() != null
            && requestContext.getSecurityContext().isSecure();
    requestContext.setProperty("app.freerouting.authenticatedApiKey", authenticatedPrincipal);
    requestContext.setSecurityContext(
        new jakarta.ws.rs.core.SecurityContext() {
          @Override
          public java.security.Principal getUserPrincipal() {
            return () -> authenticatedPrincipal;
          }

          @Override
          public boolean isUserInRole(String role) {
            return true;
          }

          @Override
          public boolean isSecure() {
            return isSecure;
          }

          @Override
          public String getAuthenticationScheme() {
            return "BEARER";
          }
        });

    FRLogger.debug("API key validation successful for path: " + path);
  }

  /**
   * Aborts the request with a 401 Unauthorized response.
   *
   * @param requestContext The request context
   * @param message The error message
   */
  private void abortWithUnauthorized(ContainerRequestContext requestContext, String message) {
    // Build a JSON string directly — using a Map subtype (e.g. Collections$SingletonMap)
    // as the entity causes a "MessageBodyWriter not found" 500 error in Jersey because
    // the Gson provider does not register a writer for that internal JDK class.
    String jsonBody = "{\"error\":\"" + message.replace("\\", "\\\\").replace("\"", "\\\"") + "\"}";
    Response response =
        Response.status(Response.Status.UNAUTHORIZED)
            .entity(jsonBody)
            .type("application/json")
            .build();
    requestContext.abortWith(response);
  }
}
