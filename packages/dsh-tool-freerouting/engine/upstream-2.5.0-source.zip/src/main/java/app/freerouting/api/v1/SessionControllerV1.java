package app.freerouting.api.v1;

import static app.freerouting.util.gson.GsonProvider.GSON;

import app.freerouting.analytics.FRAnalytics;
import app.freerouting.api.ApiUsageFilter;
import app.freerouting.api.BaseController;
import app.freerouting.core.RoutingJob;
import app.freerouting.core.Session;
import app.freerouting.logger.FRLogger;
import app.freerouting.management.jobs.RoutingJobScheduler;
import app.freerouting.management.sessions.SessionManager;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.UUID;

/**
 * JAX-RS controller for routing session lifecycle management.
 *
 * <p>A <em>session</em> groups one or more routing jobs under a single caller identity. Sessions
 * are created per EDA-tool invocation and are associated with the authenticated user's UUID.
 *
 * <h2>Endpoints</h2>
 *
 * <ul>
 *   <li>{@code POST /v1/sessions/create} — create a new session; requires the {@code
 *       Freerouting-Environment-Host} header.
 *   <li>{@code GET /v1/sessions/list} — list all sessions owned by the caller.
 *   <li>{@code GET /v1/sessions/{sessionId}} — retrieve details of a specific session.
 *   <li>{@code GET /v1/sessions/{sessionId}/logs} — retrieve all log entries for a session.
 * </ul>
 *
 * <p>All endpoints authenticate the caller via {@link
 * app.freerouting.api.BaseController#authenticateUser()} using the {@code Freerouting-Profile-ID}
 * request header.
 */
@Path("/v1/sessions")
@Tag(
    name = "Sessions",
    description = "Session management endpoints for creating and managing routing sessions")
public class SessionControllerV1 extends BaseController {

  @Context private HttpHeaders httpHeaders;

  /** Default constructor for SessionControllerV1. */
  public SessionControllerV1() {}

  /**
   * Lists all sessions for the authenticated user.
   *
   * @return Response containing session IDs list
   */
  @Operation(
      summary = "List all sessions",
      description =
          "Retrieves a list of all routing sessions accessible to the authenticated user.")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "List of session IDs retrieved successfully",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON,
                    examples =
                        @ExampleObject(
                            value =
                                "[\"550e8400-e29b-41d4-a716-446655440000\","
                                    + " \"660e8400-e29b-41d4-a716-446655440001\"]")))
      })
  @GET
  @Path("/list")
  @Produces(MediaType.APPLICATION_JSON)
  public Response listSessions() {
    // Authenticate the user
    UUID userId = authenticateUser();

    // filter the list of sessions to only include the ones that the user has access
    // to
    var response = GSON.toJson(SessionManager.getInstance().listSessionIds(userId));
    FRAnalytics.apiEndpointCalled("GET v1/sessions/list", "", response, userId);
    return Response.ok(response).build();
  }

  /**
   * Creates a new session.
   *
   * @return Response containing created Session
   */
  @Operation(
      summary = "Create new session",
      description =
          "Creates a new routing session for the authenticated user. This is Step 1 of the routing"
              + " pipeline. Next, call enqueue_job using the returned sessionId.",
      parameters = {
        @Parameter(
            name = "Freerouting-Environment-Host",
            in = ParameterIn.HEADER,
            description =
                "Identifies the calling EDA tool and its version in the format '<name>/<version>'"
                    + " (e.g. 'KiCad/10.0', 'EasyEDA/1.0'). Required on all protected endpoints.",
            required = true,
            example = "KiCad/10.0",
            schema = @Schema(type = "string", pattern = "^[^/]+/[^/]+$"))
      })
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Session created successfully",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON,
                    schema = @Schema(implementation = Session.class))),
        @ApiResponse(
            responseCode = "400",
            description = "Missing or invalid Freerouting-Environment-Host header",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON,
                    examples =
                        @ExampleObject(
                            value =
                                "{\"error\":\"The 'Freerouting-Environment-Host' request header is"
                                    + " required...\"}"))),
        @ApiResponse(
            responseCode = "500",
            description = "Failed to create session",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON,
                    examples = @ExampleObject(value = "{}")))
      })
  @POST
  @Path("/create")
  @Produces(MediaType.APPLICATION_JSON)
  public Response createSession() {
    // Authenticate the user
    UUID userId = authenticateUser();

    // The EnvironmentHostValidationFilter guarantees this header is present and
    // well-formed (<name>/<version>) before the controller is reached.
    String host = httpHeaders.getHeaderString("Freerouting-Environment-Host");
    String authHeader = httpHeaders.getHeaderString("Authorization");
    String apiKeyHash = ApiUsageFilter.hashBearerToken(authHeader);

    // create a new session using the authenticated user as the owner
    Session newSession = SessionManager.getInstance().createSession(userId, host, apiKeyHash);
    if (newSession == null) {
      return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("{}").build();
    } else {
      var response = GSON.toJson(newSession);
      FRAnalytics.apiEndpointCalled("POST v1/sessions/create", "", response, userId);
      return Response.ok(response).build();
    }
  }

  /**
   * Retrieves details of a specific session.
   *
   * @param sessionId Session ID parameter
   * @return Response containing Session details
   */
  @Operation(
      summary = "Get session details",
      description = "Retrieves detailed information about a specific routing session by its ID.")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Session details retrieved successfully",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON,
                    schema = @Schema(implementation = Session.class))),
        @ApiResponse(
            responseCode = "404",
            description = "Session not found",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON,
                    examples = @ExampleObject(value = "{}")))
      })
  @GET
  @Path("/{sessionId}")
  @Produces(MediaType.APPLICATION_JSON)
  public Response getSession(
      @Parameter(
              description = "Unique identifier of the session",
              example = "550e8400-e29b-41d4-a716-446655440000")
          @PathParam("sessionId")
          String sessionId) {
    // Authenticate the user
    UUID userId = authenticateUser();

    // Return one session with the id of sessionId
    Session session = SessionManager.getInstance().getSession(sessionId, userId);
    if (session == null) {
      return Response.status(Response.Status.NOT_FOUND).entity("{}").build();
    } else {
      var response = GSON.toJson(session);
      FRAnalytics.apiEndpointCalled("GET v1/sessions/" + sessionId, "", response, userId);
      return Response.ok(response).build();
    }
  }

  /**
   * Retrieves logs for a session.
   *
   * @param sessionId Session ID parameter
   * @return Response containing session logs
   */
  @Operation(
      summary = "Get session logs",
      description = "Retrieves all log entries associated with a specific routing session.")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Session logs retrieved successfully",
            content = @Content(mediaType = MediaType.APPLICATION_JSON)),
        @ApiResponse(
            responseCode = "404",
            description = "Session not found",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON,
                    examples = @ExampleObject(value = "{}")))
      })
  @GET
  @Path("/{sessionId}/logs")
  @Produces(MediaType.APPLICATION_JSON)
  public Response logs(
      @Parameter(
              description = "Unique identifier of the session",
              example = "550e8400-e29b-41d4-a716-446655440000")
          @PathParam("sessionId")
          String sessionId) {
    // Authenticate the user
    UUID userId = authenticateUser();

    // Return one session with the id of sessionId
    Session session = SessionManager.getInstance().getSession(sessionId, userId);
    if (session == null) {
      return Response.status(Response.Status.NOT_FOUND).entity("{}").build();
    }

    var logEntries = FRLogger.getLogEntries();
    var logs = logEntries.getEntries(null, session.id);

    var response = GSON.toJson(logs);
    FRAnalytics.apiEndpointCalled("GET v1/sessions/" + sessionId + "/logs", "", response, userId);
    return Response.ok(response).build();
  }

  /**
   * Binds the specified session to the GUI visualizer for monitoring.
   *
   * @param sessionId Session ID parameter
   * @return Response status
   */
  @Operation(
      summary = "Set session as currently monitored",
      description =
          "Binds the specified active API session and its board to the visible GUI visualizer for"
              + " real-time routing display.")
  @ApiResponses(
      value = {
        @ApiResponse(responseCode = "200", description = "Session monitor status set successfully"),
        @ApiResponse(responseCode = "404", description = "Session or active job board not found")
      })
  @jakarta.ws.rs.PUT
  @Path("/{sessionId}/monitor")
  @Produces(MediaType.APPLICATION_JSON)
  public Response monitorSession(
      @Parameter(
              description = "Unique identifier of the session",
              example = "550e8400-e29b-41d4-a716-446655440000")
          @PathParam("sessionId")
          String sessionId) {
    UUID userId = authenticateUser();

    var guiSettings = app.freerouting.Freerouting.globalSettings.guiSettings;
    if (!guiSettings.isEnabled || !guiSettings.isRunning) {
      return Response.status(Response.Status.BAD_REQUEST)
          .entity(
              GSON.toJson(
                  java.util.Map.of("error", "GUI is not running, cannot monitor session visually")))
          .build();
    }
    Session session = SessionManager.getInstance().getSession(sessionId, userId);
    if (session == null) {
      return Response.status(Response.Status.NOT_FOUND)
          .entity(GSON.toJson(java.util.Map.of("error", "Session not found")))
          .build();
    }

    RoutingJob targetJob = null;
    synchronized (RoutingJobScheduler.getInstance().jobs) {
      for (RoutingJob job : RoutingJobScheduler.getInstance().jobs) {
        if (job != null && session.getId().equals(job.sessionId)) {
          targetJob = job;
          break;
        }
      }
    }

    if (targetJob == null || targetJob.board == null) {
      return Response.status(Response.Status.NOT_FOUND)
          .entity(
              GSON.toJson(
                  java.util.Map.of(
                      "error", "Active routing job or board not found for this session")))
          .build();
    }

    SessionManager.getInstance().setMonitoredSessionId(session.getId());
    FRAnalytics.apiEndpointCalled(
        "PUT v1/sessions/" + sessionId + "/monitor", "", "{\"monitored\":true}", userId);
    return Response.ok(
            "{\"success\":true,\"message\":\"Session is now actively monitored in GUI\"}")
        .build();
  }
}
