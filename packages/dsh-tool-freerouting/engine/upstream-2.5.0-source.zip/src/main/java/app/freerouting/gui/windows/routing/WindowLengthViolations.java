package app.freerouting.gui.windows.routing;

import app.freerouting.board.model.items.Item;
import app.freerouting.board.state.CoordinateTransform;
import app.freerouting.gui.board.BoardFrame;
import app.freerouting.gui.windows.board.WindowObjectListWithFilter;
import app.freerouting.gui.workspace.GuiBoardManager;
import app.freerouting.gui.workspace.progress.RatsNest;
import app.freerouting.rules.Net;
import app.freerouting.rules.NetClass;
import app.freerouting.rules.Nets;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

/** Displays nets whose routed lengths violate their rules. */
public class WindowLengthViolations extends WindowObjectListWithFilter {

  /** Creates a new instance of WindowLengthViolations. */
  public WindowLengthViolations(BoardFrame boardFrame) {
    super(boardFrame);
    setLanguage(boardFrame.getLocale());

    this.setTitle(tm.getText("title"));
    this.listEmptyMessage.setText(tm.getText("listEmpty"));
  }

  @Override
  protected void fillList() {
    RatsNest ratsnest = this.boardFrame.boardPanel.boardHandling.getRatsnest();
    Nets netList = this.boardFrame.boardPanel.boardHandling.getRoutingBoard().rules.nets;
    SortedSet<LengthViolation> lengthViolations = new TreeSet<>();
    for (int netIndex = 1; netIndex <= netList.maxNetNumber(); netIndex++) {
      double currentViolationLength = ratsnest.getLengthViolation(netIndex);
      if (currentViolationLength != 0) {
        LengthViolation currentLengthViolation =
            new LengthViolation(netList.get(netIndex), currentViolationLength);
        lengthViolations.add(currentLengthViolation);
      }
    }

    for (LengthViolation currentViolation : lengthViolations) {
      this.addToList(currentViolation);
    }
    this.list.setVisibleRowCount(Math.min(lengthViolations.size(), DEFAULT_TABLE_SIZE));
  }

  @Override
  protected void selectInstances() {
    List<Object> selectedViolations = list.getSelectedValuesList();
    if (selectedViolations.isEmpty()) {
      return;
    }
    Set<Item> selectedItems = new TreeSet<>();
    for (int i = 0; i < selectedViolations.size(); i++) {
      LengthViolation currentViolation = (LengthViolation) selectedViolations.get(i);
      selectedItems.addAll(currentViolation.net.getItems());
    }
    GuiBoardManager boardHandling = boardFrame.boardPanel.boardHandling;
    boardHandling.selectItems(selectedItems);
    boardHandling.zoomSelection();
  }

  private class LengthViolation implements Comparable<LengthViolation> {

    final Net net;
    final double violationLength;

    LengthViolation(Net net, double violationLength) {
      this.net = net;
      this.violationLength = violationLength;
    }

    @Override
    public int compareTo(LengthViolation other) {
      return this.net.name.compareToIgnoreCase(other.net.name);
    }

    @Override
    public String toString() {
      CoordinateTransform coordinateTransform =
          boardFrame.boardPanel.boardHandling.coordinateTransform;
      NetClass netClass = this.net.getNetClass();
      float length = (float) coordinateTransform.boardToUser(this.net.getTraceLength());
      if (violationLength > 0) {
        return tm.getText(
            "length_violation_max_message",
            this.net.name,
            String.valueOf(length),
            String.valueOf(
                (float) coordinateTransform.boardToUser(netClass.getMaximumTraceLength())));
      }
      return tm.getText(
          "length_violation_min_message",
          this.net.name,
          String.valueOf(length),
          String.valueOf(
              (float) coordinateTransform.boardToUser(netClass.getMinimumTraceLength())));
    }
  }
}
