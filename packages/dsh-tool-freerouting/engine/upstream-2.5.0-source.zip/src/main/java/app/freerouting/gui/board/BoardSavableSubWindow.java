package app.freerouting.gui.board;

import app.freerouting.logger.FRLogger;
import java.awt.Rectangle;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/** Subwindow of the board frame, whose location and visibility can be saved and read from disc. */
public abstract class BoardSavableSubWindow extends BoardSubWindow {

  /** Reads the data of this frame from disc. Returns false, if the reading failed. */
  public boolean read(ObjectInputStream objectStream) {
    try {
      SavedAttributes savedAttributes = (SavedAttributes) objectStream.readObject();
      this.setBounds(savedAttributes.bounds);
      this.setVisible(savedAttributes.isVisible);
      return true;
    } catch (Exception e) {
      FRLogger.error("SelectParameterWindow.read: read failed", e);
      return false;
    }
  }

  /** Saves this frame to disk. */
  public void save(ObjectOutputStream objectStream) {
    SavedAttributes savedAttributes = new SavedAttributes(this.getBounds(), this.isVisible());

    try {
      objectStream.writeObject(savedAttributes);
    } catch (IOException e) {
      FRLogger.error("BoardSubWindow.save: save failed", e);
    }
  }

  /** Refresh the displayed values in this window. To be overwritten in derived classes. */
  public void refresh() {}

  /**
   * Called when the window has been moved to a different display with a different
   * GraphicsConfiguration (e.g. different DPI scaling). Re-packs the window and refreshes displayed
   * values so that component sizes and font metrics are recomputed for the new display.
   */
  @Override
  protected void onGraphicsConfigurationChanged() {
    pack();
    refresh();
    revalidate();
    repaint();
  }

  /** Type for attributes of this class, which are saved to an Objectstream. */
  private static class SavedAttributes implements Serializable {

    public final Rectangle bounds;
    public final boolean isVisible;

    public SavedAttributes(Rectangle bounds, boolean isVisible) {
      this.bounds = bounds;
      this.isVisible = isVisible;
    }
  }
}
